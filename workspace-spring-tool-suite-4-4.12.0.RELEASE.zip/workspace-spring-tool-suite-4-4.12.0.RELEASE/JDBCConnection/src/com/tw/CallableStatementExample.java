package com.tw;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.CallableStatement;
import java.sql.ResultSet;

public class CallableStatementExample {
	public static void main(String[] args) {
		try {
			// Establishing a connection
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/practicedb", "root",
					"root");

			// Creating a callable statement
			String sql = "{CALL getUserDetails(?)}";
			CallableStatement callableStatement = connection.prepareCall(sql);
			callableStatement.setInt(1, 1003); // Assuming 1 is the user ID parameter

			// Executing the query
			ResultSet resultSet = callableStatement.executeQuery();

			// Processing the result set
			while (resultSet.next()) {
				System.out.println("User ID: " + resultSet.getInt("id"));
				System.out.println("Username: " + resultSet.getString("name"));
				System.out.println("Email: " + resultSet.getString("email"));
				System.out.println("Age: " + resultSet.getInt("age"));

			}

			// Closing the resources
			resultSet.close();
			callableStatement.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
