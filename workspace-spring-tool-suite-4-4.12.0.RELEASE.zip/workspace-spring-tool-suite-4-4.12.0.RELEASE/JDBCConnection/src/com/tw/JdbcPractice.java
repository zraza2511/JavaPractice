package com.tw;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JdbcPractice {
	public static void main(String[] args) {

		try {
			// 1 Load the driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// 2 connect with DB by Connection DriverManager
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/practicedb", "root", "root");

			// 3 Created statement for executing select query
			Statement st = con.createStatement();

			// 4 get executed data in result set
			ResultSet rs = st.executeQuery("SELECT * from users;");

			while (rs.next()) {

				System.out.println(
						"user name is :: " + rs.getString("name") + " &  user email is :: " + rs.getString("email"));

			}
			// 5 connection close
			con.close();
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
