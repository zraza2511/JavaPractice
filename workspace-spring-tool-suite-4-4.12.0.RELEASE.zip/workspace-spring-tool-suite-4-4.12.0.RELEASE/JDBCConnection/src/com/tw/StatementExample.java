package com.tw;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

public class StatementExample {
    public static void main(String[] args) {
        try {
            // Establishing a connection
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/practicedb", "root", "root");

            // Creating a statement
            Statement statement = connection.createStatement();

            // Executing a query
            String sql = "SELECT * FROM users";
            ResultSet resultSet = statement.executeQuery(sql);

            // Processing the result set
            while (resultSet.next()) {
                System.out.println("User ID: " + resultSet.getInt("id"));
                System.out.println("Username: " + resultSet.getString("name"));
            }

            // Closing the resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
