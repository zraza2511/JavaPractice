package com.tw;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TestPreparedStat {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/practicedb","root","root");
			
			PreparedStatement pr=con.prepareStatement("select * from users where id=? and name=?");
			pr.setInt(1, 1001);
			pr.setString(2, "Zeeshan");
			
			ResultSet rs=pr.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString("name"));
			}
			
			PreparedStatement pr2=con.prepareStatement("insert into users values(?,?,?)");
			pr2.setInt(1, 1007);
			pr2.setString(2, "Taufeeq");
			pr2.setString(3, "Taufeeq@gmail.com");
	
			int execute = pr2.executeUpdate();
			System.out.println(execute);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
