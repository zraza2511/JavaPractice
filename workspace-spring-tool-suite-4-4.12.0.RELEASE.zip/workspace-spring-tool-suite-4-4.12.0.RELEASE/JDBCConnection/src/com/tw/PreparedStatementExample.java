package com.tw;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PreparedStatementExample {
    public static void main(String[] args) {
        try {
            // Establishing a connection
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/practicedb", "root", "root");

            // Creating a prepared statement
            String sql = "SELECT * FROM users WHERE name = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, "Zeeshan");

            // Executing the query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Processing the result set
            while (resultSet.next()) {
                System.out.println("User ID: " + resultSet.getInt("id"));
                System.out.println("Username: " + resultSet.getString("name"));
            }

            // Closing the resources
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
