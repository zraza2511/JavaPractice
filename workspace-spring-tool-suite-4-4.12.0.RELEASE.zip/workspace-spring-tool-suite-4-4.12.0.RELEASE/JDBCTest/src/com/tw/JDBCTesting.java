package com.tw;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCTesting {

	public static void main(String[] args) {

		try {
			// 1 Load the driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// 2 connect with DB by Connection DriverManager
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbctest", "root", "root");

			// 3 Created statement for executing select query
			Statement st = con.createStatement();

			// 4 get executed data in result set
			ResultSet rs = st.executeQuery("SELECT * FROM user_data;");

			while (rs.next()) {
				System.out.println("user_id: " + rs.getString("userid") + " user_name: " + rs.getString("username")
						+ " password: " + rs.getString("userpassword"));
			}

			// 5 connection close
			con.close();

		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}

	}

}
