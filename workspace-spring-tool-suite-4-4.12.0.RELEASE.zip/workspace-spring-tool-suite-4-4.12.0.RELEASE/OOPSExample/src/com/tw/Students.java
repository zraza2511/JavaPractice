package com.tw;

public abstract class Students {

	private long id;
	private String name="abc";
	
	public void printName() {
		System.out.println(name);
	}
	
	public abstract void printId(long id);
}
