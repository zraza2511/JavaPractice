package com.tw;

public class MainTest {

	public static void main(String[] args) {
		College college = new College();

		Professor prof1 = new Professor("Dr. Smith", 1001, "Computer Science");
		Professor prof2 = new Professor("Dr. Johnson", 1002, "Mathematics");

		Student student1 = new Student("Alice", 2001, "Computer Science");
		Student student2 = new Student("Bob", 2002, "Mathematics");
		Student student3 = new Student("Charlie", 2003, "Physics");

		Course course1 = new Course("Data Structures", 3001, prof1);
		Course course2 = new Course("Calculus", 3002, prof2);

		college.addStudent(student1);
		college.addStudent(student2);
		college.addStudent(student3);
		college.addProfessor(prof1);
		college.addProfessor(prof2);

		course1.enrollStudent(student1);
		course2.enrollStudent(student2);
		course2.enrollStudent(student3);

		college.addCourse(course1);
		college.addCourse(course2);

		System.out.println("Students in the college:");
		college.listStudents();

		System.out.println("\nProfessors in the college:");
		college.listProfessors();

		System.out.println("\nCourses in the college:");
		college.listCourses();
	}
}
