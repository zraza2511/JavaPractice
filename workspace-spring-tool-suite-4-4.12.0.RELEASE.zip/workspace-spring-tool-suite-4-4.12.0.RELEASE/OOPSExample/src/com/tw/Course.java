package com.tw;

import java.util.ArrayList;
import java.util.List;

public class Course {
	private String courseName;
	private int courseCode;
	private Professor professor;
	private List<Student> enrolledStudents;

	public Course(String courseName, int courseCode, Professor professor) {
		this.courseName = courseName;
		this.courseCode = courseCode;
		this.professor = professor;
		this.enrolledStudents = new ArrayList<>();
	}

	public String getCourseName() {
		return courseName;
	}

	public int getCourseCode() {
		return courseCode;
	}

	public Professor getProfessor() {
		return professor;
	}

	public void enrollStudent(Student student) {
		enrolledStudents.add(student);
	}

	public List<Student> getEnrolledStudents() {
		return enrolledStudents;
	}

	public String getCourseDetails() {
		StringBuilder details = new StringBuilder("Course: " + courseName + " (Code: " + courseCode + ")\nProfessor: "
				+ professor.getName() + "\nEnrolled Students:\n");
		for (Student student : enrolledStudents) {
			details.append(student.getName()).append("\n");
		}
		return details.toString();
	}
}
