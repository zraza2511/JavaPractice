package com.tw;

public class Student extends Person {
    private String major;

    public Student(String name, int id, String major) {
        super(name, id);
        this.major = major;
    }

    public String getMajor() {
        return major;
    }

    @Override
    public String getDetails() {
        return "Student: " + getName() + " (ID: " + getId() + "), Major: " + major;
    }
}
