package com.tw;

public class Professor extends Person {
	private String department;

	public Professor(String name, int id, String department) {
		super(name , id);
		this.department=department;
			}

	public String getDepartment() {
		return department;
	}

	@Override
	public String getDetails() {
		return "Professor: " + getName() + " (ID: " + getId() + "), Department: " + department;
	}

}
