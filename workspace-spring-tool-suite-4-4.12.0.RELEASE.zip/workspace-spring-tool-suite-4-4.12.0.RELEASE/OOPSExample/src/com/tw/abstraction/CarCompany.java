package com.tw.abstraction;

public abstract class CarCompany {
	
	public abstract void startEngine(String starts, String name);
	public abstract void stopEngine(String stops, String name);
	
	public void driver() {
		System.out.println("How Can I Help You");
	}


}
