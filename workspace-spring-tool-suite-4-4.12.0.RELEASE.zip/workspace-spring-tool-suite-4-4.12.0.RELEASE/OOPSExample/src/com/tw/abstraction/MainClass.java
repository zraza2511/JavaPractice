package com.tw.abstraction;

public class MainClass {

	public static void main(String[] args) {
		CarCompany obj=new Bmw();
		
		obj.startEngine("once", "Bmw car");
		obj.stopEngine("once", "Bmw car");
		
		
		
	}

}
