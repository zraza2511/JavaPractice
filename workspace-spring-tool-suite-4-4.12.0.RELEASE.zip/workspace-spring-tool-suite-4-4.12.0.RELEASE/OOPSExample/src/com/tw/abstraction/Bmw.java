package com.tw.abstraction;

public class Bmw extends CarCompany {

	@Override
	public void startEngine(String starts, String name) {
		if("once".equals(starts) && "Bmw car".equals(name)) {
			System.out.println(starts + " You start your car you can Drive your " + name);
		}

	}

	@Override
	public void stopEngine(String stops, String name) {
		if("once".equals(stops) && "Bmw car".equals(name)) {
			System.out.println(stops + " You off your car can not Drive your " + name);
		}
		

	}

}
