package com.tw.matches;

public interface Tournament {
    void startTournament();
    void endTournament();
    String getStandings();
}
