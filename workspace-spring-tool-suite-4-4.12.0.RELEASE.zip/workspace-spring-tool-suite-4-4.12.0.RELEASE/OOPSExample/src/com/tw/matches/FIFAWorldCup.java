package com.tw.matches;

public interface FIFAWorldCup extends Tournament {
    void startMatch(String teamA, String teamB);
    void updateScore(String teamA, int scoreA, String teamB, int scoreB);
    int[] getScore(String teamA, String teamB);
    void endMatch(String teamA, String teamB);
}
