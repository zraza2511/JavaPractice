package com.tw.matches;

public class FIFAWorldCupImpl extends AbstractFIFAWorldCup {

    @Override
    public void startMatch(String teamA, String teamB) {
        System.out.println("Starting match between " + teamA + " and " + teamB);
        currentMatches.put(teamA + "-" + teamB, new int[]{0, 0});
    }

    @Override
    public void updateScore(String teamA, int scoreA, String teamB, int scoreB) {
        System.out.println("Updating score: " + teamA + " " + scoreA + " - " + teamB + " " + scoreB);
        currentMatches.put(teamA + "-" + teamB, new int[]{scoreA, scoreB});
    }

    @Override
    public int[] getScore(String teamA, String teamB) {
        return currentMatches.getOrDefault(teamA + "-" + teamB, new int[]{-1, -1});
    }

    @Override
    public void endMatch(String teamA, String teamB) {
        System.out.println("Ending match between " + teamA + " and " + teamB);
        int[] score = currentMatches.remove(teamA + "-" + teamB);
        if (score != null) {
            if (score[0] > score[1]) {
                updateStandings(teamA);
            } else if (score[0] < score[1]) {
                updateStandings(teamB);
            }
        }
    }

    public static void main(String[] args) {
        FIFAWorldCupImpl fifaWorldCup = new FIFAWorldCupImpl();
        fifaWorldCup.startTournament();
        fifaWorldCup.startMatch("France", "Brazil");
        fifaWorldCup.updateScore("France", 1, "Brazil", 2);
        int[] score = fifaWorldCup.getScore("France", "Brazil");
        System.out.println("Current score of France vs Brazil: " + score[0] + " - " + score[1]);
        fifaWorldCup.endMatch("France", "Brazil");
        fifaWorldCup.endTournament();
    }
}
