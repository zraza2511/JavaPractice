package com.tw.matches;

import java.util.HashMap;
import java.util.Map;

public abstract class AbstractFIFAWorldCup implements FIFAWorldCup {

    protected Map<String, Integer> standings = new HashMap<>();
    protected Map<String, int[]> currentMatches = new HashMap<>();

    @Override
    public void startTournament() {
        System.out.println("Starting the FIFA World Cup tournament...");
    }

    @Override
    public void endTournament() {
        System.out.println("Ending the FIFA World Cup tournament...");
        System.out.println(getStandings());
    }

    @Override
    public String getStandings() {
        StringBuilder sb = new StringBuilder("Standings:\n");
        for (Map.Entry<String, Integer> entry : standings.entrySet()) {
            sb.append(entry.getKey()).append(": ").append(entry.getValue()).append(" points\n");
        }
        return sb.toString();
    }

    protected void updateStandings(String winningTeam) {
        standings.put(winningTeam, standings.getOrDefault(winningTeam, 0) + 3);
    }
}
