package com.tw;

import java.util.ArrayList;
import java.util.List;

public class College {
    private List<Student> students;
    private List<Professor> professors;
    private List<Course> courses;

    public College() {
        this.students = new ArrayList<>();
        this.professors = new ArrayList<>();
        this.courses = new ArrayList<>();
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void addProfessor(Professor professor) {
        professors.add(professor);
    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void listStudents() {
        for (Student student : students) {
            System.out.println(student.getDetails());
        }
    }

    public void listProfessors() {
        for (Professor professor : professors) {
            System.out.println(professor.getDetails());
        }
    }

    public void listCourses() {
        for (Course course : courses) {
            System.out.println(course.getCourseDetails());
        }
    }
}
