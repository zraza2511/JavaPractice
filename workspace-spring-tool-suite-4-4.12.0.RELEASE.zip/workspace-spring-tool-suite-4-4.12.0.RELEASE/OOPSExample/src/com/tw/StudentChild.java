package com.tw;

public class StudentChild extends Students {

	@Override
	public void printId(long id) {
		System.out.println(id);
	}

}
