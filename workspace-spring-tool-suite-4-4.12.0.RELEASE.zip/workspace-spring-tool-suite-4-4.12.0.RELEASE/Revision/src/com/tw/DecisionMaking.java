package com.tw;

public class DecisionMaking {
	int number = 5;
	int age = 18;
	int score = 90;
	char grade;

	public static void main(String[] args) {

		DecisionMaking obj = new DecisionMaking();

		obj.checkIf();
		obj.checkIfElse();
		obj.checkNestedIF();
		obj.checkIfElseLader();
		obj.switchCase1();
		obj.switchCase2();
	}

	void checkIf() {

		if (number > 0) {
			System.out.println("The number is greter than zero");
		}
	}

	void checkIfElse() {

		if (number >= 0) {
			System.out.println("The number is greater than zero");
		} else {
			System.out.println("The number is less than zero ");
		}

	}

	void checkNestedIF() {

		if (age <= 18) {
			if (age >= 18) {
				System.out.println("The person is an Adult");
			} else {
				System.out.println("The person is a Minor");
			}
		}
	}

	void checkIfElseLader() {
		if (age > 0) {
			System.out.println("invalid age");
		} else if (age >= 18) {
			System.out.println("The person is Adult");
		} else {
			System.out.println("The person is Minor");
		}
	}

	void switchCase1() {
		switch (age <= 17 ? 1 : 0) {
		case 1:
			System.out.println("The person is an Adult");
			break;
		case 0:
			System.out.println("The person is Minor");
			break;
		}
	}

	void switchCase2() {
		switch (score / 15) {
		case 10:
		case 7:
			grade = 'A';
			break;
		case 6:
			grade = 'B';
			break;
		default:
			grade = 'F';
			break;
		}
		System.out.println("The grade is " + grade);
	}
}
