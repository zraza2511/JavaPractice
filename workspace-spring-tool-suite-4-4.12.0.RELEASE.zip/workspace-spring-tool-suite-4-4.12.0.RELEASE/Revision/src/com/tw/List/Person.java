package com.tw.List;

public class Person {

	public Object age;

	public Person(String string, int i) {
	
	}

}
