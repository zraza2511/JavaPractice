package com.tw.List;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class ArrayListClass {
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("Hello!");
		System.out.println("add :" + list);
		list.remove(0);
		System.out.println("remove :" + list);
		list.add("Hello!");
		list.get(0);
		System.out.println("get :" + list);
		ArrayList<String> list1 = new ArrayList<>(Arrays.asList("a", "b", "c", "d"));

		for (int i = 0; i < list.size(); i++) {
			System.out.println("for loop size :" + list1.size());
		}

		for (String i : list1) {
			System.out.println("for each :" + i);
		}

		Iterator<String> iterator = list1.iterator();
		while (iterator.hasNext()) {
			System.out.println("iterator :" + iterator.next());
		}

		String[] array = new String[list1.size()];
		array = list1.toArray(array);
		System.out.println("toArray :" + Arrays.toString(array));

		Collections.sort(list1);
		System.out.println("Sorting to ArrayList :" + list1);

		System.out.println("Checking :" + list1.contains("a"));
		System.out.println("Size :" + list1.size());

		List<String> sublist = list1.subList(1, 3);
		System.out.println("Original list: " + list1);
		System.out.println("Sublist: " + sublist);

		class Person {
			String name;
			int age;

			Person(String name, int age) {
				this.name = name;
				this.age = age;
			}

			@Override
			public String toString() {
				return name + ": " + age;
			}
		}
		ArrayList<Person> people = new ArrayList<>();
		people.add(new Person("Junaid", 29));
		people.add(new Person("Zeeshan", 26));
		people.add(new Person("Amir", 23));
		people.add(new Person("Sohel", 22));

		// Print the list before sorting
		System.out.println("Before sorting:");
		for (Person person : people) {
			System.out.println(person);
		}

		// Sorting by age
		people.sort(Comparator.comparingInt(p -> p.age));

		// Print the list after sorting
		System.out.println("\nAfter sorting by age:");
		for (Person person : people) {
			System.out.println(person);

			// Create a shallow copy of the ArrayList
			ArrayList<String> copy = new ArrayList<>(list1);
			System.out.println("Original list: " + list1);
			System.out.println("Copied list: " + copy);
			list1.set(0, "z");
			System.out.println("After modifying the original list:");
			System.out.println("Original list: " + list1);
			System.out.println("Copied list: " + copy);

		}
	}

}
