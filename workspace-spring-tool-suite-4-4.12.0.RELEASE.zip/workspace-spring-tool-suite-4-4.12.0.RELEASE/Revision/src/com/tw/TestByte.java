package com.tw;

public class TestByte {
	String name = "Techweaver";
	static char ch = 97;

	void method() {
		int x = 10;
		System.out.println("Local Variable " + x);
	}

	void method1() {
		System.out.println("Instance Variable " + name);
	}

	void method3() {
		System.out.println("Static Variable " + ch);
	}

	public static void main(String args[]) {
		TestByte obj = new TestByte();

		obj.method();
		obj.method1();
		obj.method3();
	}

}
