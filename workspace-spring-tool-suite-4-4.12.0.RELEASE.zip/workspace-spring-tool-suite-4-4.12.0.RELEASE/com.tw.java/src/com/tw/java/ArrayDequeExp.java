package com.tw.java;

import java.util.ArrayDeque;
import java.util.Deque;

public class ArrayDequeExp {

	public static void main(String[] args) {
		Deque<Integer> d1=new ArrayDeque<>();
		
		//Exception in thread "main" java.lang.NullPointerException
		//d1.addFirst(null);
		
		d1.addFirst(10);
		d1.addFirst(30);
		d1.addFirst(10);
		d1.addFirst(30);
		
		d1.addLast(0);
		
		d1.offerFirst(1);
		d1.offerLast(1000);
		
		System.out.println(d1);
		
		
	}

}
