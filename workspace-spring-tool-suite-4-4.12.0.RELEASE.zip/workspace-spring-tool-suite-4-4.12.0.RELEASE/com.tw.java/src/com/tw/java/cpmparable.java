package com.tw.java;

public interface cpmparable {

}
