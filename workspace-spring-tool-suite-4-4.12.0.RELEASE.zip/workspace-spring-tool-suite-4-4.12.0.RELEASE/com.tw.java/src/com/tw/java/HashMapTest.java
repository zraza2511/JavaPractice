package com.tw.java;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HashMapTest {

	public static void main(String[] args) {
		// An object that maps keys to values.
		// A map cannot contain duplicate keys;each key can map to at most one value.

		Map<Integer, String> m1 = new HashMap<>();

		m1.put(1, null);
		m1.put(null, null);
		m1.put(3, "a");
		m1.put(2, "a");

		m1.put(21, null);
		m1.put(null, null);
		m1.put(33, "a");
		m1.put(22, "a");

		for (Map.Entry<Integer, String> v : m1.entrySet()) {
			Integer key = v.getKey();
			String val = v.getValue();

			System.out.println("Key is: " + key + " and Value is: " + val);
		}

		System.out.println(m1);

		List<Employee> techweaveremployees = Arrays.asList(new Employee(1, 1000, "a"), new Employee(2, 1000, "aa"),
				new Employee(3, 1000, "aaa"), new Employee(4, 1000, "aaaa"));

		List<Employee> stallememployees = Arrays.asList(new Employee(1, 1000, "b"), new Employee(2, 1000, "bb"),
				new Employee(3, 1000, "bbb"), new Employee(4, 1000, "bbbb"));

		Map<String, List<Employee>> empMap = new HashMap<>();
		empMap.put("Touheed manager1", techweaveremployees);
		empMap.put("Zeeshan manager1", stallememployees);

		System.out.println(empMap);

		for (Map.Entry<String, List<Employee>> employee : empMap.entrySet()) {
			System.out.println(employee.getKey() + "   ====  " + employee.getValue());
		}
	}

}
