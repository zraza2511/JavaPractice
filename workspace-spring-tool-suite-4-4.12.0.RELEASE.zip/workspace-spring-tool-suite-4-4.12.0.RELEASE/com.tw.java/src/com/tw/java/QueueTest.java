package com.tw.java;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueTest {

	public static void main(String[] args) {

		Queue<Integer> q1 = new PriorityQueue<>();

		q1.add(20);
		q1.add(4);
		q1.add(20);
		q1.add(20);
		q1.add(2);
		// Exception in thread "main" java.lang.NullPointerException
		// q1.add(null);

		System.out.println(q1);

		q1.remove();
		System.out.println(q1);

		// ========================================================//

		Comparator<Integer> obj = (a, b) -> b - a;

		Comparator<Integer> num = (a, b) -> b - a;
		Queue<Integer> q2 = new PriorityQueue<>(obj);

		q2.add(20);
		q2.add(4);
		q2.add(20);
		q2.add(20);
		q2.add(2);

		System.out.println("q2 " + q2);

		// =======================================================//

		// ========================================================//

		Comparator<String> str = (a, b) -> b.compareTo(a);

		Queue<String> q3 = new PriorityQueue<>(str);
		q3.add("d");
		q3.add("a");
		q3.add("d");
		q3.add("z");
		q3.add("x");

		System.out.println("q3 " + q3);
	}

}
