package com.tw.java;

import java.util.Stack;

public class BalancedBrackets {
	public static boolean isBalanced(String expression) {
		Stack<Character> stack = new Stack<>();
		for (char ch : expression.toCharArray()) {
			if (ch == '(') {
				stack.push(')');
			} else if (ch == '{') {
				stack.push('}');
			} else if (ch == '[') {
				stack.push(']');
			} else if (ch == ')' || ch == '}' || ch == ']') {
				if (stack.isEmpty() || stack.pop() != ch) {
					return false;
				}
			}

		}
		return stack.isEmpty();
	}

	public static void main(String[] args) {
		String expression = "{[()]}";
		System.out.println(isBalanced(expression));
	}
}
