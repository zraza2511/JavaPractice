package com.tw.java;

import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class LinkedHashSetTest {

	public static void main(String[] args) {
		
		//insertion order
		Set<String> s1=new LinkedHashSet<>();
		
		//s1.add(null);
		s1.add("d");
		s1.add("a");
		s1.add("c");
		//s1.add(null);
		s1.add("d");
		s1.add("a");
		s1.add("c");
		
		System.out.println(s1);
		
		//Ascending order sort
		//Natural order
		//when we want ascending order data and no duplicate values and 0 null value then use TreeSet
		Set<String> s2=new TreeSet<>();
		s2.addAll(s1);
		s2.add("a");
		System.out.println(s2);
		
		Set<Integer> s3=new TreeSet<>();
		
		s3.add(30);
		s3.add(1);
		s3.add(22);
		s3.add(4);
		s3.add(2);
		
		System.out.println(s3);
		//s3.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.out.println(s3.stream().sorted(Comparator.reverseOrder()).toList());
	}

}
