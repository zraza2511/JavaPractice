package com.tw.java;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class MapTest {

	public static void main(String[] args) {
		Map<Integer, Employee> hash1=new HashMap<Integer, Employee>();
		
		hash1.put(1, new Employee(1, 10000, "Zeeshan"));
		hash1.put(2, new Employee(2, 20000, "Junaidudding"));
		hash1.put(3, new Employee(3, 30000, "Junaid"));
		hash1.put(4, new Employee(4, 40000, "Sohel"));
		hash1.put(5, new Employee(5, 50000, "xyz"));
		
		System.out.println(hash1);
		System.out.println(hash1.get(5));
		System.out.println(hash1.containsKey(null));
		
		List<String> l1=new ArrayList<String>();
		l1.add("a");
		l1.add("b");
		l1.add("a");
		l1.add("b");
		l1.add("c");
		l1.add("d");
		
		Map<String, String> m1=new HashMap<>();
		
		for (String val : l1) {
			if(m1.containsKey(val)) {
				System.out.println("Duplicates Values from list: "+val);
			}else {
				m1.put(val, val);
			}
		}
		
		System.out.println(m1);
		
		//==============================================================//
		Map<String, String> linkedhash1=new LinkedHashMap<>();
		linkedhash1.put(null, null);
		linkedhash1.put("m1", null);
		linkedhash1.put("m2", null);
		
		linkedhash1.put("m3", "val1");
		linkedhash1.put("m4", "val2");
		
		linkedhash1.put("a", null);
		linkedhash1.put("b", null);
		linkedhash1.put("aa", null);
		
		System.out.println(linkedhash1);
		
		//====================================================================//
		System.out.println("=================================Linked HashMap================================");
		List<Employee> emp1=Arrays.asList(
				new Employee(1, 1000000, "Md Junaid1"),
				new Employee(2, 2000000, "Junaiduddin1"),
				new Employee(3, 3000000, "Zeeshan1"),
				new Employee(4, 4000000, "Sohel1")
				
				);
		List<Employee> emp2=Arrays.asList(
				new Employee(1, 1000000, "Md Junaid2"),
				new Employee(2, 2000000, "Junaiduddin2"),
				new Employee(3, 3000000, "Zeeshan2"),
				new Employee(4, 4000000, "Sohel2")
				
				);
		
		List<Employee> emp3=Arrays.asList(
				new Employee(1, 1000000, "Md Junaid3"),
				new Employee(2, 2000000, "Junaiduddin3"),
				new Employee(3, 3000000, "Zeeshan3"),
				new Employee(4, 4000000, "Sohel3")
				
				);
		
		//System.out.println(emp);
		
		List<String> managers=new ArrayList<>();
		managers.add("Musharraf");
		managers.add("Faizan");
		managers.add("Taufeeq");
		
		Map<String, List<Employee>> mapEmp=new LinkedHashMap<>();
		mapEmp.put(managers.get(0), emp1);
		mapEmp.put(managers.get(1), emp2);
		mapEmp.put(managers.get(2), emp3);
		
		System.out.println(mapEmp);
		
		for (Map.Entry<String, List<Employee>> data : mapEmp.entrySet()) {
			System.out.println(data.getKey() +" --- "+ data.getValue());
		}
		
		//=========================================================Tree Map====================
		System.out.println("======================================TreeMAp===========================================================");
		Map<String, List<Employee>> treeMap=new TreeMap<>();
		treeMap.put(managers.get(0), emp1);
		treeMap.put(managers.get(1), emp2);
		treeMap.put(managers.get(2), emp3);
		try {
			treeMap.put(null, emp3);
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
				
		System.out.println(treeMap);
		for (Map.Entry<String, List<Employee>> data : treeMap.entrySet()) {
			System.out.println(data.getKey() +" --- "+ data.getValue());
		}
		
	}

}
