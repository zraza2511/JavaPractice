package com.tw.java;

import java.util.Objects;

public class Employee {
	
	private long id;
	private double salary;
	private String name;
	
	
	public Employee(long id, double salary, String name) {
		super();
		this.id = id;
		this.salary = salary;
		this.name = name;
	}

	/** 
	 * This method is used to set the ID of Employee 
	 * Suppose someone call the Employee.setId(4) the ID of employee will become 4 
	 **/
	public void setId(long idd) {
		this.id =idd;
	}

	/**
	 * This method is used to get the ID of employee
	 **/
	public long getId() {
		return this.id;
	}
	
	public void setSalary(double salaryy) {
		this.salary =salaryy;
	}
	
	public double getSalary() {
		return this.salary;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", salary=" + salary + ", name=" + name + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name, salary);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return id == other.id && Objects.equals(name, other.name)
				&& Double.doubleToLongBits(salary) == Double.doubleToLongBits(other.salary);
	}
	
	
}
