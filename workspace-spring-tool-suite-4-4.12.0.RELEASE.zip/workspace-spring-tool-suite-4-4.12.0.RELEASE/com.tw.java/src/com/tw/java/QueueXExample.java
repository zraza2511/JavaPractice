package com.tw.java;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueXExample {

	public static void main(String[] args) {

		Queue<String> Q1 = new PriorityQueue();

		Q1.add("Z");
		Q1.add("Y");
		Q1.add("A");
		Q1.add("B");
		Q1.add("S");
		Q1.add("D");
		Q1.add("O");

		System.out.println(" adding the  elements to  Q1  " + Q1);

		System.out.println(Q1.remove());
		System.out.println("===============================");
		System.out.println(Q1.isEmpty());
		System.out.println("===============================");
		System.out.println(Q1.size());
		System.out.println("===============================");
		System.out.println(Q1.isEmpty());
		System.out.println("===============================");
		System.out.println(Q1.equals(Q1));

		Queue<Integer> Q2 = new PriorityQueue<Integer>();

		Q2.add(2);
		Q2.add(3);
		Q2.add(1);
		Q2.add(100);
		Q2.add(4);

		System.out.println("===============================");
		System.out.println("it will REMOVE first value as pr assending order " + Q2.remove());

		System.out.println("===============================");
		System.out.println(" it will compair Q2 to Q1 is " + Q2.contains(Q1));

		System.out.println("===============================");
		System.out.println(Q2);
		System.out.println("it will remove first value = " + Q2.remove());

		System.out.println("===============================");
		System.out.println(Q2);

	}

}
