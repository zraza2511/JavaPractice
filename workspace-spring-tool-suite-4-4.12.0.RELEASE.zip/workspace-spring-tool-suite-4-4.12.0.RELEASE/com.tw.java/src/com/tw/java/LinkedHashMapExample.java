package com.tw.java;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapExample {

	public static void main(String[] args) {

		Map<Integer, String> m1 = new LinkedHashMap<>();

//		 adding elements to LinkedHashMap

		m1.put(1, "Volvo");
		m1.put(2, "G-Wagon");
		m1.put(3, "Porsche");
		m1.put(4, "Hammer Off-Road");

		System.out.println(m1);
		System.out.println("                  ");

		for (Map.Entry<Integer, String> entry : m1.entrySet()) {
			System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
		}
		System.out.println(m1.containsKey(1));

		System.out.println(m1.containsValue("Volvo"));

	}

}
