package com.tw.java;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class HashSetTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set<String> s1 = new HashSet<>();
		s1.add("a");
		s1.add(null);
		s1.add(null);

		s1.add("a");
		s1.add(null);
		s1.add("a");
		s1.add(null);
		s1.add("ab");
		s1.add(null);

		System.out.println(s1);

		List<String> l1 = new LinkedList<>();
		l1.add("a");
		l1.add(null);
		l1.add(null);

		l1.add("a");
		l1.add(null);
		l1.add("a");
		l1.add(null);
		l1.add("ab");
		l1.add(null);

		System.out.println(l1);

		Set<String> s2 = new HashSet<>();
		s2.addAll(l1);

		System.out.println(s2);
		s2.forEach(System.out::println);

	}
}
