package com.tw.java;
import java.util.*;
import java.lang.*;


public class Cars implements Comparable<Cars>{
	
	private int carSeries;
	private String model;
	
	public Cars(int carSeries, String model) {
		this.carSeries = carSeries;
		this.model = model;
	}
	
//	getter for cars series 
	public int getcarSeries() {
		return carSeries;
	}
	
//	setter for cars series 
	public void setcarSeries(int carSeries) {
		this.carSeries =carSeries;
	}

//	Getter for cars model
	public String getmodel() {
		return model;
	}
	
//	setter for cars model
	public void setmodel(String model) {
		this.model =model;
	}

	@Override
	public int compareTo(Cars o) {
		return this.carSeries - o.carSeries;
		
		
	}

	@Override
	public String toString() {
		return "Cars [carSeries=" + carSeries + ", model=" + model + "]";
	}
	
	public static void main(String[] args) {
		List <Cars> cr= new ArrayList<>();
		
		cr.add(new Cars(05,"volvoGen5"));
		cr.add(new Cars(44,"porche Z4"));
		cr.add(new Cars(46,"Hammer offroad"));
		cr.add(new Cars(3,"compact EndiviorD"));
		
		Collections.sort(cr);
		for (Cars cr1 : cr) {
			System.out.println(cr1);
	}
	
	
		
		
		
		

	}

}
