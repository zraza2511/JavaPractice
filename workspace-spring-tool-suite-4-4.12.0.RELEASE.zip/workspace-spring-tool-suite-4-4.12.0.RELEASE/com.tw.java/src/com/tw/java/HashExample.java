package com.tw.java;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class HashExample {

	public static void main(String[] args) {

		Map<Integer, String> m1 = new HashMap<>();

		m1.put(1, "junaid");
		m1.put(2, "aamir");
		m1.put(3, "zeeshan");
		m1.put(4, "farman");

		System.out.println(m1);

		for (Map.Entry<Integer, String> v : m1.entrySet()) {
			Integer key = v.getKey();
			String val = v.getValue();

			System.out.println("key is  : " + key + "  value is : " + val);

		}

		Map<String, Integer> m2 = new HashMap<>();

		// 1. put(K key, V value)
		m2.put("junaid", 29);
		m2.put("aamir", 23);
		m2.put("zeeshan", 27);
		m2.put("taha", 22);
		m2.put("farman", 24);

//		/2. get age from m2
		System.out.println("aamir age is : " + m2.get("aamir"));
		System.out.println("taha age is : " + m2.get("taha"));
//		3.remove 
		m2.remove("farman");
		System.out.println("after removing m2 is  : " + m2);

//		containKey it will check key is available or not
		System.out.println("' contain 'zeeshan' is available : " + m2.containsKey("zeeshan"));
		System.out.println("' contain 'farman' is available : " + m2.containsKey("farman"));

//		contain value it will check value is available or not
		System.out.println();
		System.out.println(" contain cheak the key is available : " + m2.containsValue(29));
		System.out.println(" contain cheak the key is available : " + m2.containsValue(21));

//		6. size 
		System.out.println(m2.size());

//		7. is check is empty or not 
		System.out.println(m1.isEmpty());
		System.out.println(m2.isEmpty());

//		8.keySet it will return the key of Map
		System.out.println(" it will return the key maen  Name of Map : " + m2.keySet());

//		9.KeyValue it will return the values of Map
		System.out.println(" it will return the values means Age of Map : " + m2.values());

//		10.entrySet
		System.out.println("Entiries in the MAP ");
		for (Entry<String, Integer> entry : m2.entrySet()) {
			System.out.println(entry.getKey() + " age is " + entry.getValue());

		}

//		11. clear() 
		m2.clear();
		System.out.println(" size of m2 after clear is : " + m2.size());

	}

}
