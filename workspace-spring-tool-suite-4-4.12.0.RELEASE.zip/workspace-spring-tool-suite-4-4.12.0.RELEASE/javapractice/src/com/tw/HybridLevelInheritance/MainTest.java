package com.tw.HybridLevelInheritance;

public class MainTest {

	public static void main(String[] args) {
		
		ElectricCar elc = new ElectricCar();
		
		System.out.println(elc.start);
		System.out.println(elc.tesla);
		System.out.println(elc.stop);
		System.out.println(elc.tesla2);
		
	}

}
