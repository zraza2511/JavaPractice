package com.tw.HybridLevelInheritance;

public interface Vehicle {
	public String start = "Please Start Your Car";

}
