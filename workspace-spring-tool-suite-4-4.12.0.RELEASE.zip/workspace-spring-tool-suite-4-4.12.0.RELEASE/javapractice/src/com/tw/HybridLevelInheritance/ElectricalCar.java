package com.tw.HybridLevelInheritance;

public interface ElectricalCar {
	public String tesla = "Please charged Your Car";

}
