package com.tw.HybridLevelInheritance;

public class car implements Vehicle {
	public String stop = "Please Off Your Car";

}
