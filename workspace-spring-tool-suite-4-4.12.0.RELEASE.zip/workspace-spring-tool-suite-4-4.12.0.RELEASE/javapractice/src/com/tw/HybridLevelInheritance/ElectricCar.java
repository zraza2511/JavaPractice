package com.tw.HybridLevelInheritance;

public class ElectricCar extends car implements ElectricalCar {
	
	public String tesla2 = "Your Car Is Fully Charged Please Remove Your Charger";

}
