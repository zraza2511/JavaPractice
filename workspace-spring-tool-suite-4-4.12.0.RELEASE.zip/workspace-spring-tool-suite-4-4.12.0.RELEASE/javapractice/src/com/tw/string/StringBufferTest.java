package com.tw.string;

public class StringBufferTest {

	public static void main(String[] args) {
	
		StringBuffer buffer = new StringBuffer(".dlroW, ");
		buffer.append("!olleH"); 
		buffer.insert(7, "avaJ"); 
		buffer.reverse(); 
		System.out.println("Insert,Reverse= "+buffer); 
		
		StringBuffer buffer1 = new StringBuffer("javaguides");
		buffer1.append(" - For Beginners");
		System.out.println("Append= "+buffer1);
		
		StringBuffer buffer2 = new StringBuffer("javaguides");
		buffer2.insert(4, " - Java");
		System.out.println("Insert= "+buffer2);
		
		StringBuffer buffer3 = new StringBuffer("javaguides");
		buffer3.delete(4, 9);
		System.out.println("Delete= "+buffer3);
		
		StringBuffer buffer4 = new StringBuffer("sediugavaj");
		buffer4.reverse();
		System.out.println("Reverse= "+buffer4); 
		
		StringBuffer buffer5 = new StringBuffer("javaguides");
		buffer5.replace(0, 4, "JavaGuides");
		System.out.println("Replace= "+buffer5);
		
		StringBuffer buffer6 = new StringBuffer("javaguides");
		int capacity = buffer6.capacity();
		System.out.println("Capacity: " + capacity);
		
		StringBuffer buffer7 = new StringBuffer("javaguides");
		int length = buffer7.length();
		System.out.println("Length: " + length); 
		
		

	}
}
