package com.tw.string;

public class StringMethod {

	public static void main(String[] args) {
		
		String str1 = "Hello";
		char result1 = str1.charAt(0);
		System.out.println("charAt- "+result1);
		
		String str2 = "Hello";
		int result2 = str2.codePointAt(0);
		System.out.println("codePointAt- "+result2);
		
		String str3 = "Hello";
		int result3 = str3.codePointBefore(2);
		System.out.println("codePointBefore- "+result3);
		
		String str4 = "Hello";
		int result4 = str4.codePointCount(0, 5);
		System.out.println("codePointCount- "+result4);
		
		String str5 = "Hello";
		String str6 = "Hello";
		System.out.println("compareTo- "+str5.compareTo(str6));
		
		String str7 = "HELLO";
		String str8 = "hello";
		System.out.println("compareToIgnoreCase- "+str7.compareToIgnoreCase(str8));
		
		String firstName = "John ";
		String lastName = "Doe";
		System.out.println("concat- "+firstName.concat(lastName));
		
		String str9 = "Hello";
		System.out.println("contains- "+str9.contains("Hel"));   
		System.out.println("contains- "+str9.contains("lo"));     
		System.out.println("contains- "+str9.contains("Hi")); 
		
		String str10 = "Hello";
		System.out.println("contentEquals- "+str10.contentEquals("Hello"));  
		System.out.println("contentEquals- "+str10.contentEquals("Helo"));      
		System.out.println("contentEquals- "+str10.contentEquals("Hi")); 
		
		char[] str11 = {'H', 'e', 'l', 'l', 'o'};
		String str12 = "";
		str12 = str12.copyValueOf(str11, 0, 5);
		System.out.println("copyValueOf- " +str12);
		
		String str13 = "Hello";
		System.out.println("endsWith- "+str13.endsWith("Hel"));   
		System.out.println("endsWith- "+str13.endsWith("llo"));   
		System.out.println("endsWith- "+str13.endsWith("o")); 
		
		String str14 = "Hello";
		String str15 = "Hello";
		String str16 = "Another String";
		System.out.println("equals- "+str14.equals(str15)); 
		System.out.println("equals- "+str14.equals(str16)); 
		
		String str17 = "Hello";
		String str18 = "HELLO";
		String str19 = "Another String";
		System.out.println("equalsIgnoreCase- "+str17.equalsIgnoreCase(str18));
		System.out.println("equalsIgnoreCase- "+str17.equalsIgnoreCase(str19));
		
		String str20 = "Hello";
		System.out.println("hashCode- "+str20.hashCode());
		
		String str21 = "Hello planet earth, you are a great planet.";
		System.out.println("indexOf- "+str21.indexOf("planet"));
		
		String str22 = "Hello";
		String str23 = "";
		System.out.println("isEmpty- "+str22.isEmpty());
		System.out.println("isEmpty- "+str23.isEmpty());
		
		String str24 = "Hello planet earth, you are a great planet.";
		System.out.println("lastIndexOf- "+str24.lastIndexOf("planet"));
		
		String txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		System.out.println("length- "+txt.length());

		String str25 = "Hello";
		System.out.println("replace- "+str25.replace('l', 'p'));
		
		String str26 = "Hello";
		System.out.println("startsWith- "+str26.startsWith("Hel"));  
		System.out.println("startsWith- "+str26.startsWith("llo"));  
		System.out.println("startsWith- "+str26.startsWith("o"));     
		
		String txt1 = "Hello World";
		System.out.println("toUpperCase- "+txt1.toUpperCase());
		System.out.println("toLowerCase- "+txt1.toLowerCase());
		
		String txt2 = "Hello World";
		System.out.println("toUpperCase- "+txt2.toUpperCase());
		System.out.println("toLowerCase- "+txt2.toLowerCase());
		
		String str27 = "       Hello World!       ";
		System.out.println("trim- "+str27);
		System.out.println("trim- "+str27.trim());


	}

}
