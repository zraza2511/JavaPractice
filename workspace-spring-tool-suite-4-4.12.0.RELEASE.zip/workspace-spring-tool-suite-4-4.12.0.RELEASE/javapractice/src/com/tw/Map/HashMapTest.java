package com.tw.Map;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

public class HashMapTest {

    public static void main(String[] args) {
        // Create a HashMap to store student names and their grades
        HashMap<String, Integer> studentGrades = new HashMap<>();

        // Add students and their grades
        studentGrades.put("Junaid", 85);
        studentGrades.put("Zeeshan", 90);
        studentGrades.put("Amir", 78);

        // Retrieve and print a specific student's grade
        String student = "Junaid";
        if (studentGrades.containsKey(student)) {
            System.out.println(student + "'s grade: " + studentGrades.get(student));
        } else {
            System.out.println(student + " is not in the list.");
        }

        // Check if a student exists in the HashMap
        String anotherStudent = "Sohel";
        if (studentGrades.containsKey(anotherStudent)) {
            System.out.println(anotherStudent + " is in the list.");
        } else {
            System.out.println(anotherStudent + " is not in the list.");
        }

        // Print all students and their grades
        for (Map.Entry<String, Integer> entry : studentGrades.entrySet()) {
            System.out.println("Student: " + entry.getKey() + ", Grade: " + entry.getValue());
        }

        // Example of using Map<String, List<String>>
        Map<String, List<String>> map = new HashMap<>();

        addToMap(map, "key1", "value1");
        addToMap(map, "key1", "value2");
        addToMap(map, "key2", "value3");

        for (Map.Entry<String, List<String>> entry : map.entrySet()) {
            String key = entry.getKey();
            List<String> values = entry.getValue();
            System.out.print(key + ": ");
            for (String value : values) {
                System.out.print(value + " ");
            }
            System.out.println();
        }
    }

    // Function to add a new item to the inventory
    public static void addItem(HashMap<String, Integer> inventory, String item, int quantity) {
        inventory.put(item, quantity);
    }

    // Function to update the quantity of an existing item
    public static void updateItemQuantity(HashMap<String, Integer> inventory, String item, int quantityChange) {
        if (inventory.containsKey(item)) {
            inventory.put(item, inventory.get(item) + quantityChange);
        } else {
            System.out.println("Item not found in inventory.");
        }
    }

    // Function to check if an item is in stock
    public static boolean isInStock(HashMap<String, Integer> inventory, String item) {
        return inventory.containsKey(item) && inventory.get(item) > 0;
    }

    // Function to print all items and their quantities
    public static void printInventory(HashMap<String, Integer> inventory) {
        System.out.println("Inventory:");
        for (Map.Entry<String, Integer> entry : inventory.entrySet()) {
            System.out.println("Item: " + entry.getKey() + ", Quantity: " + entry.getValue());
        }
    }

    // Function to add a value to a List<String> associated with a key in a Map<String, List<String>>
    public static void addToMap(Map<String, List<String>> map, String key, String value) {
        map.computeIfAbsent(key, k -> new ArrayList<>()).add(value);
    }
}
