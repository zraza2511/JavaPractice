package com.tw.Map;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapTest {
	public static void main(String[] args) {
		LinkedHashMap<String, Integer> LHM = new LinkedHashMap<>();

		// Adding entries to the LinkedHashMap
		LHM.put("One", 1);
		LHM.put("Two", 2);
		LHM.put("Three", 3);
		LHM.put("Four", 4);
		LHM.put("Five", 5);

		// Iterating over the entries in LinkedHashMap
		for (Map.Entry<String, Integer> entry : LHM.entrySet()) {
			System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
		}

		// Accessing elements
		System.out.println("Value for key 'Three': " + LHM.get("Three"));

		// Checking if a key exists
		System.out.println("Contains key 'Four': " + LHM.containsKey("Four"));

		// Checking if a value exists
		System.out.println("Contains value 5: " + LHM.containsValue(5));

		// Removing an entry
		LHM.remove("Two");
		System.out.println("After removing key 'Two': " + LHM);

		// Size of LinkedHashMap
		System.out.println("Size of LinkedHashMap: " + LHM.size());
		
	}
	
}
