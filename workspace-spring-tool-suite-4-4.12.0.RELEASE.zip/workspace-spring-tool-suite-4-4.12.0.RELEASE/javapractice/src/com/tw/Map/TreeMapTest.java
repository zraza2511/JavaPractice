package com.tw.Map;

import java.util.HashMap;
import java.util.Map;

import com.tw.oops.Employee;

public class TreeMapTest {

	public static void main(String[] args) {
		
		Integer[] array1 = {1, 2, 3, 4, 5};
		Integer[] array2 = {3, 4, 5, 6, 7};

		HashMap<Integer, Integer> hashMap = new HashMap<>();

		for (Integer integer : array1) {
		    hashMap.put(integer, integer);
		}

		for (Integer integer : array2) {
		    if (hashMap.containsKey(integer)) {
		        System.out.println(integer);
		    }
		}
	
	}

}
