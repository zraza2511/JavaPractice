package com.tw.comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Student implements Comparable<Student> {
	private String name;
	private int id;

	// Constructor to initialize Student objects
	public Student(String name, int id) {
		this.name = name;
		this.id = id;
	}

	// Getter for name
	public String getName() {
		return name;
	}

	// Setter for name
	public void setName(String name) {
		this.name = name;
	}

	// Getter for id
	public int getId() {
		return id;
	}

	// Setter for id
	public void setId(int id) {
		this.id = id;
	}

	// Overriding the compareTo method to compare students by id
	@Override
	public int compareTo(Student o) {
		return this.id - o.id; // Sorting in ascending order of id
	}

	// Overriding the toString method to provide a custom string representation of a Student object
	@Override
	public String toString() {
		return "Student [name=" + name + ", id=" + id + "]";
	}

	public static void main(String[] args) {
		List<Student> st = new ArrayList<>(); // Creating a list to hold Student objects
		
		// Adding new Student objects to the list
		st.add(new Student("Junaid", 1002));
		st.add(new Student("Amir", 1003));
		st.add(new Student("Zeeshan", 1001));
		
		// Sorting the list of students by id
		Collections.sort(st);
		
		// Printing the sorted list of students
		for (Student st1 : st) {
			System.out.println(st1);
		}
	}
}
