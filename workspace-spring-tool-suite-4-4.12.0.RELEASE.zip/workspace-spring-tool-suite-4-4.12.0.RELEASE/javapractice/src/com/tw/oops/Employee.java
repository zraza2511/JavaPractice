package com.tw.oops;

public class Employee {
	
	private long id;
	private double salary;
	private String name;
	
	/** 
	 * This method is used to set the ID of Employee 
	 * Suppose someone call the Employee.setId(4) the ID of employee will become 4 
	 **/
	public void setId(long idd) {
		this.id =idd;
	}

	/**
	 * This method is used to get the ID of employee
	 **/
	public long getId() {
		return this.id;
	}
	
	public void setSalary(double salaryy) {
		this.salary =salaryy;
	}
	
	public double getSalary() {
		return this.salary;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	
	public String getName() {
		return name;
	}
}
