package com.tw.oops;

public class Account {
	private long acc_no;
	
	public long getAcc_no(){
		return acc_no;
	}
	public void setAcc_no(long acc_no) {
		this.acc_no = acc_no;
	}

}
