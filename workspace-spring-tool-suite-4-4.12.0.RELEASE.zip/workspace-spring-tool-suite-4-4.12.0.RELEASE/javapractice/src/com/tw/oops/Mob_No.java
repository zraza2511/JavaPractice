package com.tw.oops;

public class Mob_No {

}
