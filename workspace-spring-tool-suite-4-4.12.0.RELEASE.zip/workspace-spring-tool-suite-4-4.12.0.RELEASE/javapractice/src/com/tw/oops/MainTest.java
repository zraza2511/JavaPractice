package com.tw.oops;

public class MainTest {

	public static void main(String[] args) {
		Employee e = new Employee();

		e.setId(4);
		e.setName("Junaid");
		e.setSalary(20000);

		System.out.println(e.getId() + " " + e.getName() + " " + e.getSalary());

		Account acc = new Account();
		acc.setAcc_no(7560504000L);
		System.out.println("Account No: " + acc.getAcc_no());

		Account_Name an = new Account_Name();
		an.setName("Imtiyaz");
		System.out.println("Account_Name: " + an.getName());

		Amount amt = new Amount();
		amt.setRs(35000f);
		System.out.println("Amount: " + amt.getRs());

		Student st = new Student();
		for (int i = 1; i <= 5; i++) {
			st.setId(i);
			st.setName("student" + i);
			st.setClassName("class" + i);

			System.out.println(st);

		}

	}

}
