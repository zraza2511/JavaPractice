package com.tw.oops;

public class Amount {
	private float rs;
	
	public float getRs() {
		return rs;
	}
	public void setRs(float rs) {
		this.rs = rs;
	}

}
