package com.tw.multiLevelInheritance;

public class FatherName extends GrandFather {
	public String fatherName= "Mohammed Nazeer";

}
