package com.tw.multiLevelInheritance;

public class ChildName extends FatherName {
public String childName = "Mohammed Junaid";
}
