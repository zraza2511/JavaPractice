package com.tw.multiLevelInheritance;

public class MainTest {

	public static void main(String[] args) {
		ChildName c = new ChildName();
		
		System.out.println("Child Name: "+c.childName);
		System.out.println("Father Name: "+c.fatherName);
		System.out.println("GrandFather Name: "+c.grandFatherName);

		FatherName f = new FatherName();
		
		System.out.println("Father Name: "+f.fatherName);
		System.out.println("GrandFather Name: "+f.grandFatherName);
		
		GrandFather g = new GrandFather();

		System.out.println("GrandFather Name "+g.grandFatherName);
	}

}
