package com.tw.multiLevelInheritance;

public class GrandFather {
	public String grandFatherName = "Mohammed Ameen";

}
