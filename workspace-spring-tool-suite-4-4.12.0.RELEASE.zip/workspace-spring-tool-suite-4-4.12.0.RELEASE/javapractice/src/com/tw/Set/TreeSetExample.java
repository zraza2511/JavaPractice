package com.tw.Set;

import java.util.TreeSet;
import java.util.Iterator;

public class TreeSetExample {

	public static void main(String[] args) {
		// Byte TreeSet
		TreeSet<Byte> byteSet = new TreeSet<>();
		byteSet.add((byte) 5);
		byteSet.add((byte) 3);
		byteSet.add((byte) 8);
		printSet("Byte TreeSet", byteSet);

		// Short TreeSet
		TreeSet<Short> shortSet = new TreeSet<>();
		shortSet.add((short) 500);
		shortSet.add((short) 300);
		shortSet.add((short) 800);
		printSet("Short TreeSet", shortSet);

		// Integer TreeSet
		TreeSet<Integer> intSet = new TreeSet<>();
		intSet.add(5);
		intSet.add(3);
		intSet.add(8);
		printSet("Integer TreeSet", intSet);
		// Additional collection methods on Integer TreeSet
		manipulateIntegerTreeSet(intSet);

		// Long TreeSet
		TreeSet<Long> longSet = new TreeSet<>();
		longSet.add(500L);
		longSet.add(300L);
		longSet.add(800L);
		printSet("Long TreeSet", longSet);

		// Float TreeSet
		TreeSet<Float> floatSet = new TreeSet<>();
		floatSet.add(5.5f);
		floatSet.add(3.3f);
		floatSet.add(8.8f);
		printSet("Float TreeSet", floatSet);

		// Double TreeSet
		TreeSet<Double> doubleSet = new TreeSet<>();
		doubleSet.add(5.55);
		doubleSet.add(3.33);
		doubleSet.add(8.88);
		printSet("Double TreeSet", doubleSet);

		// Character TreeSet
		TreeSet<Character> charSet = new TreeSet<>();
		charSet.add('C');
		charSet.add('A');
		charSet.add('B');
		printSet("Character TreeSet", charSet);

		// Boolean TreeSet
		TreeSet<Boolean> booleanSet = new TreeSet<>();
		booleanSet.add(true);
		booleanSet.add(false);
		printSet("Boolean TreeSet", booleanSet);
	}

	private static <T> void printSet(String setName, TreeSet<T> set) {
		System.out.println(setName + ": " + set);
	}

	private static void manipulateIntegerTreeSet(TreeSet<Integer> intSet) {
		System.out.println("\nManipulating Integer TreeSet:");
		System.out.println("Original Integer TreeSet: " + intSet);

		// Adding multiple elements using addAll
		TreeSet<Integer> moreInts = new TreeSet<>();
		moreInts.add(10);
		moreInts.add(1);
		intSet.addAll(moreInts);
		System.out.println("After addAll: " + intSet);

		// Checking if a particular element exists
		System.out.println("Contains 3? " + intSet.contains(3));

		// Checking if multiple elements exist
		System.out.println("Contains all elements of moreInts? " + intSet.containsAll(moreInts));

		// Removing an element
		intSet.remove(8);
		System.out.println("After removing 8: " + intSet);

		// Removing multiple elements using removeAll
		intSet.removeAll(moreInts);
		System.out.println("After removeAll: " + intSet);

		// Getting the size of the TreeSet
		System.out.println("Size: " + intSet.size());

		// Iterating over the TreeSet
		System.out.println("Iterating:");
		Iterator<Integer> iterator = intSet.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}

		// Clearing the TreeSet
		intSet.clear();
		System.out.println("After clearing: " + intSet);
		System.out.println("Is empty? " + intSet.isEmpty());
	}
}
