package com.tw.Set;
import java.util.LinkedHashSet;
import java.util.Iterator;


public class LinkedHashSetExp {

	    public static void main(String[] args) {
	        // Creating LinkedHashSets for different wrapper classes
	        LinkedHashSet<Integer> intSet = new LinkedHashSet<>();
	        LinkedHashSet<Double> doubleSet = new LinkedHashSet<>();
	        LinkedHashSet<Float> floatSet = new LinkedHashSet<>();
	        LinkedHashSet<Boolean> booleanSet = new LinkedHashSet<>();
	        LinkedHashSet<Character> charSet = new LinkedHashSet<>();
	        LinkedHashSet<Long> longSet = new LinkedHashSet<>();
	        LinkedHashSet<Short> shortSet = new LinkedHashSet<>();
	        LinkedHashSet<Byte> byteSet = new LinkedHashSet<>();

	        // Adding elements to the LinkedHashSets
	        intSet.add(10);
	        intSet.add(20);
	        intSet.add(30);

	        doubleSet.add(10.5);
	        doubleSet.add(20.5);
	        doubleSet.add(30.5);

	        floatSet.add(1.5f);
	        floatSet.add(2.5f);
	        floatSet.add(3.5f);

	        booleanSet.add(true);
	        booleanSet.add(false);

	        charSet.add('A');
	        charSet.add('B');
	        charSet.add('C');

	        longSet.add(100000L);
	        longSet.add(200000L);
	        longSet.add(300000L);

	        shortSet.add((short) 10);
	        shortSet.add((short) 20);
	        shortSet.add((short) 30);

	        byteSet.add((byte) 1);
	        byteSet.add((byte) 2);
	        byteSet.add((byte) 3);

	        // Displaying the LinkedHashSets
	        System.out.println("Integer LinkedHashSet: " + intSet);
	        System.out.println("Double LinkedHashSet: " + doubleSet);
	        System.out.println("Float LinkedHashSet: " + floatSet);
	        System.out.println("Boolean LinkedHashSet: " + booleanSet);
	        System.out.println("Character LinkedHashSet: " + charSet);
	        System.out.println("Long LinkedHashSet: " + longSet);
	        System.out.println("Short LinkedHashSet: " + shortSet);
	        System.out.println("Byte LinkedHashSet: " + byteSet);

	        // Using contains method
	        System.out.println("Does intSet contain 20? " + intSet.contains(20));
	        System.out.println("Does charSet contain 'D'? " + charSet.contains('D'));

	        // Using remove method
	        intSet.remove(10);
	        System.out.println("Integer LinkedHashSet after removing 10: " + intSet);

	        // Using size method
	        System.out.println("Size of doubleSet: " + doubleSet.size());

	        // Using iterator
	        System.out.println("Iterating through floatSet:");
	        Iterator<Float> floatIterator = floatSet.iterator();
	        while (floatIterator.hasNext()) {
	            System.out.println(floatIterator.next());
	        }

	        // Using isEmpty method
	        System.out.println("Is byteSet empty? " + byteSet.isEmpty());

	        // Using clear method
	        byteSet.clear();
	        System.out.println("Byte LinkedHashSet after clearing: " + byteSet);

	        // Using addAll method
	        LinkedHashSet<Integer> anotherIntSet = new LinkedHashSet<>();
	        anotherIntSet.add(40);
	        anotherIntSet.add(50);
	        intSet.addAll(anotherIntSet);
	        System.out.println("Integer LinkedHashSet after addAll: " + intSet);

	        // Using removeAll method
	        intSet.removeAll(anotherIntSet);
	        System.out.println("Integer LinkedHashSet after removeAll: " + intSet);

	        // Using retainAll method
	        intSet.add(50);
	        intSet.retainAll(anotherIntSet);
	        System.out.println("Integer LinkedHashSet after retainAll: " + intSet);

	        // Using toArray method
	        Object[] intArray = intSet.toArray();
	        System.out.println("Integer LinkedHashSet toArray: ");
	        for (Object obj : intArray) {
	            System.out.println(obj);
	        }

	        // Using forEach method
	        System.out.println("Using forEach to print elements in doubleSet:");
	        doubleSet.forEach(System.out::println);

	        // Using stream method
	        long count = floatSet.stream().count();
	        System.out.println("Count of elements in floatSet using stream: " + count);

	        // Using spliterator
	        System.out.println("Using spliterator to print elements in charSet:");
	        charSet.spliterator().forEachRemaining(System.out::println);

	        // Using hashCode method
	        System.out.println("Hash code of intSet: " + intSet.hashCode());

	        // Using equals method
	        LinkedHashSet<Integer> anotherIntSet2 = new LinkedHashSet<>(anotherIntSet);
	        System.out.println("Does intSet equal anotherIntSet2? " + intSet.equals(anotherIntSet2));

	    }
	}

