package com.tw.Set;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetExp {

	public static void main(String[] args) {

		        // Creating HashSets for different wrapper classes
		        HashSet<Integer> intSet = new HashSet<>();
		        HashSet<Double> doubleSet = new HashSet<>();
		        HashSet<Float> floatSet = new HashSet<>();
		        HashSet<Boolean> booleanSet = new HashSet<>();
		        HashSet<Character> charSet = new HashSet<>();
		        HashSet<Long> longSet = new HashSet<>();
		        HashSet<Short> shortSet = new HashSet<>();
		        HashSet<Byte> byteSet = new HashSet<>();

		        // Adding elements to the HashSets
		        intSet.add(10);
		        intSet.add(20);
		        intSet.add(30);

		        doubleSet.add(10.5);
		        doubleSet.add(20.5);
		        doubleSet.add(30.5);

		        floatSet.add(1.5f);
		        floatSet.add(2.5f);
		        floatSet.add(3.5f);

		        booleanSet.add(true);
		        booleanSet.add(false);

		        charSet.add('A');
		        charSet.add('B');
		        charSet.add('C');

		        longSet.add(100000L);
		        longSet.add(200000L);
		        longSet.add(300000L);

		        shortSet.add((short) 10);
		        shortSet.add((short) 20);
		        shortSet.add((short) 30);

		        byteSet.add((byte) 1);
		        byteSet.add((byte) 2);
		        byteSet.add((byte) 3);

		        // Displaying the HashSets
		        System.out.println("Integer HashSet: " + intSet);
		        System.out.println("Double HashSet: " + doubleSet);
		        System.out.println("Float HashSet: " + floatSet);
		        System.out.println("Boolean HashSet: " + booleanSet);
		        System.out.println("Character HashSet: " + charSet);
		        System.out.println("Long HashSet: " + longSet);
		        System.out.println("Short HashSet: " + shortSet);
		        System.out.println("Byte HashSet: " + byteSet);

		        // Using contains method
		        System.out.println("Does intSet contain 20? " + intSet.contains(20));
		        System.out.println("Does charSet contain 'D'? " + charSet.contains('D'));

		        // Using remove method
		        intSet.remove(10);
		        System.out.println("Integer HashSet after removing 10: " + intSet);

		        // Using size method
		        System.out.println("Size of doubleSet: " + doubleSet.size());

		        // Using iterator
		        System.out.println("Iterating through floatSet:");
		        Iterator<Float> floatIterator = floatSet.iterator();
		        while (floatIterator.hasNext()) {
		            System.out.println(floatIterator.next());
		        }

		        // Using isEmpty method
		        System.out.println("Is byteSet empty? " + byteSet.isEmpty());

		        // Using clear method
		        byteSet.clear();
		        System.out.println("Byte HashSet after clearing: " + byteSet);

		        // Using addAll method
		        HashSet<Integer> anotherIntSet = new HashSet<>();
		        anotherIntSet.add(40);
		        anotherIntSet.add(50);
		        intSet.addAll(anotherIntSet);
		        System.out.println("Integer HashSet after addAll: " + intSet);

		        // Using removeAll method
		        intSet.removeAll(anotherIntSet);
		        System.out.println("Integer HashSet after removeAll: " + intSet);

		        // Using retainAll method
		        intSet.add(50);
		        intSet.retainAll(anotherIntSet);
		        System.out.println("Integer HashSet after retainAll: " + intSet);
		    }	
	}
