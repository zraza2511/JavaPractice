package com.tw.List;

import java.util.LinkedList;
import java.util.Iterator;

public class LinkedListTest {
    public static void main(String[] args) {
        // Create LinkedLists for each wrapper class
        LinkedList<Integer> integerList = new LinkedList<>();
        LinkedList<Double> doubleList = new LinkedList<>();
        LinkedList<Character> characterList = new LinkedList<>();
        LinkedList<Boolean> booleanList = new LinkedList<>();
        LinkedList<Byte> byteList = new LinkedList<>();
        LinkedList<Short> shortList = new LinkedList<>();
        LinkedList<Long> longList = new LinkedList<>();
        LinkedList<Float> floatList = new LinkedList<>();
        
        // Adding elements
        integerList.add(1);
        doubleList.add(1.1);
        characterList.add('A');
        booleanList.add(true);
        byteList.add((byte) 1);
        shortList.add((short) 2);
        longList.add(1000L);
        floatList.add(2.2f);
        
        // Adding elements at specific positions
        integerList.addFirst(0);
        doubleList.addLast(2.2);
        System.err.println(integerList);
        
        // Accessing elements
        System.out.println("First element in integerList: " + integerList.getFirst());
        System.out.println("Last element in doubleList: " + doubleList.getLast());
        
        // Removing elements
        integerList.removeFirst();
        doubleList.removeLast();
        characterList.remove(Character.valueOf('A'));
        
        // Checking if the lists contain specific elements
        System.out.println("integerList contains 1: " + integerList.contains(1));
        System.out.println("booleanList contains true: " + booleanList.contains(true));
        
        // Getting the size of the lists
        System.out.println("Size of integerList: " + integerList.size());
        System.out.println("Size of doubleList: " + doubleList.size());
        
        // Iterating through the lists using an iterator
        Iterator<Integer> integerIterator = integerList.iterator();
        while (integerIterator.hasNext()) {
            System.out.println("Iterating integerList: " + integerIterator.next());
        }
        
        Iterator<Double> doubleIterator = doubleList.iterator();
        while (doubleIterator.hasNext()) {
            System.out.println("Iterating doubleList: " + doubleIterator.next());
        }
        
        // Clearing the lists
        integerList.clear();
        doubleList.clear();
        
        // Checking if the lists are empty
        System.out.println("integerList is empty: " + integerList.isEmpty());
        System.out.println("doubleList is empty: " + doubleList.isEmpty());
    }
}