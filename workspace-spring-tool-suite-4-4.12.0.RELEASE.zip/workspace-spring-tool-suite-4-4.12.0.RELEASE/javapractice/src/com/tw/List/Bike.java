package com.tw.List;

import java.util.Objects;

public class Bike {

	private String brand;
	private String type;


	public Bike(String brand, String type) {
		this.brand = brand;
		this.type = type;
		
	}

	@Override
	public String toString() {
		return brand + " " + type;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;
		Bike bike = (Bike) obj;
		return brand.equals(bike.brand) && type.equals(bike.type);
	}

	@Override
	public int hashCode() {
		return Objects.hash(brand, type);

	}

	}

