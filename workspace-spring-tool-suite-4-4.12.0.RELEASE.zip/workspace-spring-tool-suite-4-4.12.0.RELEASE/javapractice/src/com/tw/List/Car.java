package com.tw.List;

import java.util.Objects;

public class Car {

	private String make;
	private String model;
	private int year;

	public Car(String make, String model, int year) {
		this.make = make;
		this.model = model;
		this.year = year;
	}

	@Override
	public String toString() {
		return year + " " + make + " " + model;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;
		Car car = (Car) obj;
		return year == car.year && make.equals(car.make) && model.equals(car.model);
	}

	@Override
	public int hashCode() {
		return Objects.hash(make, model, year);

	}

	}

