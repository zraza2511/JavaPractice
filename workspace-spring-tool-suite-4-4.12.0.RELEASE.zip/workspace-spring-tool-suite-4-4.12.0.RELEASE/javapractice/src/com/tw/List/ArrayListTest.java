package com.tw.List;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListTest {
	public static void main(String[] args) {

		// Create an ArrayList for each wrapper class.
		ArrayList<Integer> intList = new ArrayList<>();
		ArrayList<Double> doubleList = new ArrayList<>();
		ArrayList<Character> charList = new ArrayList<>();
		ArrayList<Boolean> booleanList = new ArrayList<>();
		ArrayList<Byte> byteList = new ArrayList<>();
		ArrayList<Short> shortList = new ArrayList<>();
		ArrayList<Long> longList = new ArrayList<>();
		ArrayList<Float> floatList = new ArrayList<>();

		ArrayList<Car> carList = new ArrayList<>();
		ArrayList<Bike> bikeList = new ArrayList<>();

		// Adding elements.
		intList.add(10);
		doubleList.add(20.5);
		charList.add('A');
		booleanList.add(true);
		byteList.add((byte) 1);
		shortList.add((short) 100);
		longList.add(1000L);
		floatList.add(10.5f);

		carList.add(new Car("Toyota", "Innova", 2020));
		carList.add(new Car("Suzuki", "Swift", 2021));
		carList.add(new Car("Ford", "Mustang", 2022));

		bikeList.add(new Bike("Yamaha", "Fz"));
		bikeList.add(new Bike("Bajaj", "Pulsar"));
		bikeList.add(new Bike("Tvs", "Apachi"));

		// Adding all elements from another collection.
		ArrayList<Integer> anotherIntList = new ArrayList<>();
		anotherIntList.add(20);
		anotherIntList.add(30);
		intList.addAll(anotherIntList);

		ArrayList<Car> anotherCarList = new ArrayList<>();
		anotherCarList.add(new Car("Hyundai", "Creta", 2018));
		anotherCarList.add(new Car("Nissan", "Magnite", 2019));
		carList.addAll(anotherCarList);

		ArrayList<Bike> anotherBikeList = new ArrayList<>();
		anotherBikeList.add(new Bike("KTM", "Duke"));
		anotherBikeList.add(new Bike("Hero", "Splender"));
		bikeList.addAll(anotherBikeList);

		// Check if the list contains specific elements
		System.out.println("intList contains 10 : " + intList.contains(10));
		System.out.println("doubleList contains 20.5 : " + doubleList.contains(20.5));

		System.out.println(
				"carList contains Toyota Innova 2020 : " + carList.contains(new Car("Toyota", "Innova", 2020)));

		System.out.println("bikeList contains Yamaha Sport : " + bikeList.contains(new Bike("Yamaha", "Sport")));

		// Check if the contains all element from another collection.
		System.out.println("intlist contains all elements  of anotherIntList : " + intList.containsAll(anotherIntList));
		System.out.println("carList contains all elements of amotherCarList : " + carList.containsAll(anotherCarList));

		System.out.println(
				"bikeList contains all elements of anotherBikeList : " + bikeList.containsAll(anotherBikeList));

		// Remove elements.
		intList.remove(Integer.valueOf(10));
		doubleList.remove(Double.valueOf(20.5));

		carList.remove(new Car("Ford", "Mustang", 2022));

		bikeList.remove(new Bike("Tvs", "Apachi"));

		// Remove all elements from another collection
		intList.removeAll(anotherIntList);

		carList.removeAll(anotherCarList);

		bikeList.removeAll(anotherBikeList);

		// Retain only the elements in the that are contained in the specified
		// collection
		ArrayList<Integer> retainList = new ArrayList<>();
		retainList.add(10);
		intList.add(10);
		intList.add(30);
		intList.add(10);
		intList.retainAll(retainList);

		ArrayList<Car> retainCarList = new ArrayList<>();
		retainCarList.add(new Car("Toyota", "Innova", 2020));
		carList.add(new Car("Ford", "Mustang", 2022)); // Adding back for demonstration
		carList.retainAll(retainCarList);

		ArrayList<Bike> retainBikeList = new ArrayList<>();
		retainBikeList.add(new Bike("Yamaha", "Fz"));
		bikeList.add(new Bike("Tvs", "Apachi"));
		bikeList.retainAll(retainBikeList);

		// Get the size of the list
		System.out.println("Size of intList : " + intList.size());
		System.out.println("Size DoubleList : " + doubleList.size());

		System.out.println("Size of carList : " + carList.size());

		System.out.println("Size of bikeList : " + bikeList.size());

		// Convert to array
		Object[] intArray = intList.toArray();
		for (Object obj : intArray) {
			System.out.println("Element in intArray : " + obj);
		}

		Object[] carArray = carList.toArray();
		for (Object obj : carArray) {
			System.out.println("Element in carArray : " + obj);
		}

		Object[] bikeArray = bikeList.toArray();
		for (Object obj : bikeArray) {
			System.out.println("Element in bikeArray : " + obj);
		}

		// Clear the list
		charList.clear();

		carList.clear();

		bikeList.clear();
		
		// Check if the list is empty
		System.out.println("charList is empty : " + charList.isEmpty());

		System.out.println("carList is empty : " + carList.isEmpty());
		
		System.out.println("bikeList is empty : " + bikeList.isEmpty());

		// Iterate through the list using an iterator
		Iterator<Integer> iterator = intList.iterator();
		while (iterator.hasNext()) {
			System.out.println("Iterating intList : " + iterator.next());
		}

		carList.add(new Car("Toyota", "Innova", 2020));
		carList.add(new Car("Suzuki", "Swift", 2021));
		carList.add(new Car("Ford", "Mustang", 2022));
		Iterator<Car> carIterator = carList.iterator();
		while (carIterator.hasNext()) {
			System.out.println("Iterating carList : " + carIterator.next());
		}
		
		bikeList.add(new Bike("Yamaha", "Fz"));
		bikeList.add(new Bike("Bajaj", "Pulsar"));
		bikeList.add(new Bike("Tvs", "Apachi"));
		Iterator<Bike> bikeIterator = bikeList.iterator();
		while (bikeIterator.hasNext()){
			System.out.println("Iterating bikeList : " + bikeIterator.next());
		}

		// Iterator using enhanced for loop
		for (Boolean bool : booleanList) {
			System.out.println("Element in booleanList : " + bool);
		}

	}

}
