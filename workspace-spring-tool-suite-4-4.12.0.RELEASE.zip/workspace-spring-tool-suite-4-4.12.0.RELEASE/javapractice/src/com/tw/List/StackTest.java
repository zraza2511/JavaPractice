package com.tw.List;

import java.util.EmptyStackException;
import java.util.Iterator;
import java.util.Stack;

public class StackTest<E> {
	    private Stack<E> stack;

	    // Constructor
	    public StackTest() {
	        this.stack = new Stack<>();
	    }

	    // Push an element onto the stack
	    public void push(E element) {
	        stack.push(element);
	    }

	    // Pop an element from the stack
	    public E pop() {
	        if (stack.isEmpty()) {
	            throw new EmptyStackException();
	        }
	        return stack.pop();
	    }

	    // Peek at the top element of the stack without removing it
	    public E peek() {
	        if (stack.isEmpty()) {
	            throw new EmptyStackException();
	        }
	        return stack.peek();
	    }

	    // Check if the stack is empty
	    public boolean isEmpty() {
	        return stack.isEmpty();
	    }

	    // Get the size of the stack
	    public int size() {
	        return stack.size();
	    }

	    // Search for an element in the stack (1-based position from the top)
	    public int search(Object element) {
	        return stack.search(element);
	    }

	    // Convert the stack to an array
	    public Object[] toArray() {
	        return stack.toArray();
	    }

	    // Convert the stack to an array of a specific type
	    public <T> T[] toArray(T[] a) {
	        return stack.toArray(a);
	    }

	    // Iterate through the stack
	    public Iterator<E> iterator() {
	        return stack.iterator();
	    }

	    // Clear the stack
	    public void clear() {
	        stack.clear();
	    }

	    // String representation of the stack
	    @Override
	    public String toString() {
	        return "StackTest" + stack;
	    }

	    // Main method for demonstration
	    public static void main(String[] args) {
	        // Integer stack
	        StackTest<Integer> intStack = new StackTest<>();
	        intStack.push(1);
	        intStack.push(2);
	        intStack.push(3);
	        System.out.println("Integer Stack: " + intStack);  

	        // Double stack
	        StackTest<Double> doubleStack = new StackTest<>();
	        doubleStack.push(1.1);
	        doubleStack.push(2.2);
	        doubleStack.push(3.3);
	        System.out.println("Double Stack: " + doubleStack);  

	        // Float stack
	        StackTest<Float> floatStack = new StackTest<>();
	        floatStack.push(1.1f);
	        floatStack.push(2.2f);
	        floatStack.push(3.3f);
	        System.out.println("Float Stack: " + floatStack);  

	        // Character stack
	        StackTest<Character> charStack = new StackTest<>();
	        charStack.push('a');
	        charStack.push('b');
	        charStack.push('c');
	        System.out.println("Character Stack: " + charStack);  

	        // Boolean stack
	        StackTest<Boolean> boolStack = new StackTest<>();
	        boolStack.push(true);
	        boolStack.push(false);
	        boolStack.push(true);
	        System.out.println("Boolean Stack: " + boolStack); 

	        // Byte stack
	        StackTest<Byte> byteStack = new StackTest<>();
	        byteStack.push((byte) 1);
	        byteStack.push((byte) 2);
	        byteStack.push((byte) 3);
	        System.out.println("Byte Stack: " + byteStack);  

	        // Short stack
	        StackTest<Short> shortStack = new StackTest<>();
	        shortStack.push((short) 1);
	        shortStack.push((short) 2);
	        shortStack.push((short) 3);
	        System.out.println("Short Stack: " + shortStack); 

	        // Long stack
	        StackTest<Long> longStack = new StackTest<>();
	        longStack.push(1L);
	        longStack.push(2L);
	        longStack.push(3L);
	        System.out.println("Long Stack: " + longStack);  
	    }
	}



