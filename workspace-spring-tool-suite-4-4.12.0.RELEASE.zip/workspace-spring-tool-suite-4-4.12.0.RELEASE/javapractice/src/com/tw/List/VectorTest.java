package com.tw.List;


import java.util.Vector;
import java.util.Iterator;

public class VectorTest {
    public static void main(String[] args) {
        // Create Vectors for each wrapper class
        Vector<Integer> integerVector = new Vector<>();
        Vector<Double> doubleVector = new Vector<>();
        Vector<Character> characterVector = new Vector<>();
        Vector<Boolean> booleanVector = new Vector<>();
        Vector<Byte> byteVector = new Vector<>();
        Vector<Short> shortVector = new Vector<>();
        Vector<Long> longVector = new Vector<>();
        Vector<Float> floatVector = new Vector<>();
        
        // Adding elements
        integerVector.add(1);
        doubleVector.add(1.1);
        characterVector.add('A');
        booleanVector.add(true);
        byteVector.add((byte) 1);
        shortVector.add((short) 2);
        longVector.add(1000L);
        floatVector.add(2.2f);
        
        // Adding elements at specific positions
        integerVector.add(0, 0);
        doubleVector.add(2.2);
        
        // Accessing elements
        System.out.println("First element in integerVector: " + integerVector.firstElement());
        System.out.println("Last element in doubleVector: " + doubleVector.lastElement());
        
        // Removing elements
        integerVector.remove(0);
        doubleVector.remove(doubleVector.size() - 1);
        characterVector.remove(Character.valueOf('A'));
        
        // Checking if the vectors contain specific elements
        System.out.println("integerVector contains 1: " + integerVector.contains(1));
        System.out.println("booleanVector contains true: " + booleanVector.contains(true));
        
        // Getting the size of the vectors
        System.out.println("Size of integerVector: " + integerVector.size());
        System.out.println("Size of doubleVector: " + doubleVector.size());
        
        // Iterating through the vectors using an iterator
        Iterator<Integer> integerIterator = integerVector.iterator();
        while (integerIterator.hasNext()) {
            System.out.println("Iterating integerVector: " + integerIterator.next());
        }
        
        Iterator<Double> doubleIterator = doubleVector.iterator();
        while (doubleIterator.hasNext()) {
            System.out.println("Iterating doubleVector: " + doubleIterator.next());
        }
        
        // Clearing the vectors
        integerVector.clear();
        doubleVector.clear();
        
        // Checking if the vectors are empty
        System.out.println("integerVector is empty: " + integerVector.isEmpty());
        System.out.println("doubleVector is empty: " + doubleVector.isEmpty());
        
        // Demonstrating remaining methods
        // Adding elements again for further demonstration
        integerVector.add(1);
        integerVector.add(3);
        
        // Using containsAll, removeAll, retainAll with another collection
        Vector<Integer> anotherIntegerVector = new Vector<>();
        anotherIntegerVector.add(1);
        anotherIntegerVector.add(3);
        System.out.println("integerVector contains all elements of anotherIntegerVector: " + integerVector.containsAll(anotherIntegerVector));
        
        integerVector.removeAll(anotherIntegerVector);
        System.out.println("After removeAll, integerVector: " + integerVector);
        
        integerVector.add(1);
        integerVector.add(3);
        integerVector.retainAll(anotherIntegerVector);
        System.out.println("After retainAll, integerVector: " + integerVector);
        
        // Converting to array
        Object[] integerArray = integerVector.toArray();
        for (Object obj : integerArray) {
            System.out.println("Element in integerArray: " + obj);
        }
    }
}