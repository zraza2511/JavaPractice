package com.tw.multipleLevelInheritance;

public class Child2 extends Parent {
	public String myName= "Mohammed Khaled";
}
