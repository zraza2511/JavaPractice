package com.tw.multipleLevelInheritance;

public class MainTest {

	public static void main(String[] args) {
		Child c1 = new Child();
		System.out.println("Father Name: "+c1.fatherName);
		System.out.println("Child Name: "+c1.myName);
		
		
		Child2 c2 = new Child2();
		System.out.println("Father Name: "+c2.fatherName);
		System.out.println("Child2 Name: "+c2.myName);
		
		Child3 c3 = new Child3();
		System.out.println("Father Name: "+c3.fatherName);
		System.out.println("Child3 Name: "+c3.myName);

	}

}
