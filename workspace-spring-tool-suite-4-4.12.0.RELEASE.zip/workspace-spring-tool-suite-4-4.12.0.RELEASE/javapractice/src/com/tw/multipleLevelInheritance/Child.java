package com.tw.multipleLevelInheritance;

public class Child extends Parent {
	public String myName= "Mohammed Junaid";
}
