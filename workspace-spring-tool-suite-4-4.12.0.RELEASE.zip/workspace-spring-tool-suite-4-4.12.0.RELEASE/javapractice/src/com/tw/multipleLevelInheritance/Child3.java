package com.tw.multipleLevelInheritance;

public class Child3 extends Parent {
	public String myName= "Mohammed Fahad";
}
