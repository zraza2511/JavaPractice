package com.tw.multipleLevelInheritance;

public class Parent {
	public String fatherName= "Mohammed Nazeer";

}
