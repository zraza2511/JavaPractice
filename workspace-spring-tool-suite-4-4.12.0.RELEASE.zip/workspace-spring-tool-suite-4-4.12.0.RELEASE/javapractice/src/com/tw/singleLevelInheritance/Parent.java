package com.tw.singleLevelInheritance;

public class Parent {
	public String fatherName= "Mohammed Nazeer";

}
