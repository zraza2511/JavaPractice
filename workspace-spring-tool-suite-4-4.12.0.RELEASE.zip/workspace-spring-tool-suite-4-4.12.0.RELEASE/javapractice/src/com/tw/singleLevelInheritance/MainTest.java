package com.tw.singleLevelInheritance;

public class MainTest {

	public static void main(String[] args) {
      Child c = new Child();
      System.out.println("Father Name: "+c.fatherName); 
      System.out.println("Child Name: "+c.myName);
      
      
	}

}
