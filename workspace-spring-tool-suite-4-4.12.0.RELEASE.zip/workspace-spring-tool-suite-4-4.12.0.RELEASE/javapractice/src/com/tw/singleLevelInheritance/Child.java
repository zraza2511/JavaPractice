package com.tw.singleLevelInheritance;

public class Child extends Parent {
	public String myName= "Mohammed Junaid";
}
