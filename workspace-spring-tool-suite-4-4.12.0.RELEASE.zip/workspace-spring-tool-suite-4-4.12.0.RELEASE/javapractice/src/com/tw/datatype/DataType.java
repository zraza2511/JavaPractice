package com.tw.datatype;

public class DataType {

	public static void main(String[] args) {
		
		boolean b=true;
		System.out.println("Boolean: "+b);

		char myGrade = 97;
		System.out.println("Char: "+myGrade);

		byte myNum = 100;
		System.out.println("Byte: "+myNum);
		
		short myNum1 = 5000;
		System.out.println("Short: "+myNum1);

		int myNum2 = 100000;
		System.out.println("Int: "+myNum2);
		
		long myNum3 = 15000000000L;
		System.out.println("Long: "+myNum3);

		float myNum4 = 5.75f;
		System.out.println("Float: "+myNum4);
		
		double myNum5 = 19.99d;
		System.out.println("Double: "+myNum5);

	}

}
