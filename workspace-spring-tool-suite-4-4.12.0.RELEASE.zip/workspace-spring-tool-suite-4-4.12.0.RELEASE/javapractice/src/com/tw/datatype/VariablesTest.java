package com.tw.datatype;

public class VariablesTest {

	//Non static var/non static field 
	//instance var can be access by creating object
	 int instancevar=10;
	
	 static int staticvar=90;
	
	public static void main(String[] args) {
		//local variable
		int num1=10;
		System.out.println(num1);
		
		//Cannot make a static reference to the non-static field instancevar
		///System.out.println(instancevar);
		
		VariablesTest obj=new VariablesTest();
		System.out.println(obj.instancevar);
		
		System.out.println(staticvar);
		
		Employee e=new Employee();
		System.out.println(e.id);
		System.out.println(e.name);
		System.out.println(e.age);
		System.out.println(e.salary);
		System.out.println(e.department);
		
		System.out.println(Employee.mobilenum);
		
	}
	

}
