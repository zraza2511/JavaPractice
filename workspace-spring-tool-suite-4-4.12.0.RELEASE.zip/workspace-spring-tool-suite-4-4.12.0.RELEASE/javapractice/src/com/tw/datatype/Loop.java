package com.tw.datatype;

public class Loop {

	public static void main(String[] args) {
		
		int a = 1;
		for (a=1; a<=5; a++) {
			System.out.print("a"+a);
			
		}
		
		int b = 0;
		while (b < 5) {
		  System.out.println("b"+b);
		  b++;
		}
		
		int c = 0;
		do {
			System.out.println(c);
			c++;
		}
		while (c <5);
	
		
		}

		}

	


