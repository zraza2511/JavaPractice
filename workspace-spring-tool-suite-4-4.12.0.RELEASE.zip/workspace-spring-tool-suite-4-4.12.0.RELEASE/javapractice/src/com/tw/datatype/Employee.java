package com.tw.datatype;

public class Employee {
	
	// Non static var instance var
	long id =1;
	String name="Noman";
	double salary=100000;
	int age=23;
	String department="IT";
	
	//static var
	static int mobilenum=98766555;

}
