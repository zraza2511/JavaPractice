package com.tw.datatype;

public class Testing {

	public static void main(String[] args) {

		// even number and odd number
		// even number the number divided by 2 ==0
		// odd number the can't number divided by 2 ==0
		//evenodd(10);
		
		boolean isp=isPrime(4);
		if(isp)
			System.out.println("prime number");
		else
			System.out.println("Not prime");
		
		String str="LAALA";
		
		//System.out.println(str.length() -1);
		pillandrom(str);
		
		fibonacci(10);
		System.out.println();
		int val=353;
		String strval=Integer.toString(val);
		String [] strarray=strval.split("");
		
		Integer fv=Integer.parseInt(strarray[0]) ;
		Integer lv=Integer.parseInt(strarray[strarray.length-1]) ;
		System.out.println(fv+lv);
	}

	private static void fibonacci(int num) {
		
		int val1=0, val2=1;
		
		for (int i = 0; i < num; i++) {
			
			System.out.print(" "+val1);
			int val3=val2+val1;
			val1=val2;
			val2=val3;
					}
		
	}
	//
	private static void pillandrom(String str) {
		String str2="";
		for (int i = str.length() -1; i >= 0; i--) {
			char ch=str.charAt(i);
			str2= str2 +ch;
		}
		
		if(str.equals(str2))
			System.out.println("Pillandrom");
		else
			System.out.println("Not pallandrom");
	}

	private static boolean isPrime(int i) {
		if(i <= 1) {
			return false;
		}
		
		if(i% 2 == 0) {
			return false;
		}
		
		return true;
	}

	private static void evenodd(int a) {
		for (int i = 0; i < a; i++) {

			if (i % 2 == 0)
				System.out.println("even number " + i);
			else
				System.out.println("odd number " + i);

		}
	}

}
