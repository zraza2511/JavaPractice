package com.tw.Deque;
import java.util.ArrayDeque;
import java.util.Deque;
public class ArrayDequeTest {
		    public static void main(String[] args) {
	        Deque<String> deque = new ArrayDeque<>();

	        // Adding elements to the deque
	        deque.addFirst("A"); // Adds to the head
	        deque.addLast("B");  // Adds to the tail
	        deque.offerFirst("C"); // Another way to add to the head
	        deque.offerLast("D");  // Another way to add to the tail

	        // Displaying the deque
	        System.out.println("Deque after additions: " + deque);

	        // Removing elements from the deque
	        String head = deque.removeFirst(); // Removes from the head
	        String tail = deque.removeLast();  // Removes from the tail

	        // Displaying the removed elements and the deque
	        System.out.println("Removed from head: " + head);
	        System.out.println("Removed from tail: " + tail);
	        System.out.println("Deque after removals: " + deque);

	        // Peeking at elements
	        System.out.println("Peek first: " + deque.peekFirst()); // Peeks at the head
	        System.out.println("Peek last: " + deque.peekLast());  // Peeks at the tail
	    }
	}


