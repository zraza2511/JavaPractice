package com.tw.constructors;

public class ParameterizedConstructor {

	private int id;
	private String name;

	public ParameterizedConstructor(int id, String name) {
		this.id = id;
		this.name = name;

	}

	public void displayDetails() {
		System.out.println("Parameterized Id: " + id);
		System.out.println("Parameterized Name: " + name);
	}
}
