package com.tw.constructors;

public class DefaultConstructors {
	
	public int id=100;
	public String name="Captain";
	
}

