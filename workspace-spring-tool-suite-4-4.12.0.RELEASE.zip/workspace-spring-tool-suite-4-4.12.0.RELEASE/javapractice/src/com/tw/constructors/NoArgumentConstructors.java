package com.tw.constructors;

public class NoArgumentConstructors {

	public int id;
	public String name;
	
	public NoArgumentConstructors () {
		id = 1003;
		name = "Ameer Sohel";
	}
	
}
