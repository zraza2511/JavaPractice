package com.tw.constructors;

public class CopyConstructors {

	private int id;
	private String name;

	public CopyConstructors(int id, String name) {

		this.id = id;
		this.name = name;

	}

	public CopyConstructors(CopyConstructors copyConstructors) {
		this.id = copyConstructors.id;
		this.name = copyConstructors.name;

	}

	@Override
	public String toString() {
		return "CopyConstructors [ID=" + id + ", Name=" + name + "]";
	}

}
