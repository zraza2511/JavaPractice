package com.tw.constructors;

public class MainMethod {

	public static void main(String[] args) {

		DefaultConstructors obj = new DefaultConstructors();
		System.out.println("Default ID: " + obj.id);
		System.out.println("Default Name: " + obj.name);
		
		System.out.println();

		ParameterizedConstructor obj2 = new ParameterizedConstructor(102, "Zeeshan Raza");
		obj2.displayDetails();
		
		System.out.println();
		
		NoArgumentConstructors obj3 = new NoArgumentConstructors();
		System.out.println("NoArgumentConstructors ID: " + obj3.id);
		System.out.println("NoArgumentConstructors Name: " + obj3.name);
		
		System.out.println();
		
	  
		CopyConstructors obj4 = new CopyConstructors(20, "Imtiyaz");
	  	CopyConstructors obj5 = new CopyConstructors(obj4);
	        
	    System.out.println(obj4); 
	    System.out.println(obj5);
	    }


	}


