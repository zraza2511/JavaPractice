package com.tw.encapsulation;
public class MainTest {

	public static void main(String[] args) {
		Car c = new Car();
		
		c.setModel("BMW");
		c.setYear(2024);
		c.setMilage(20.5);
		
		System.out.println("Car Name: "+c.getModel());
		System.out.println("Year: "+c.getYear());
		System.out.println("Milage: "+c.getMilage());
		

	}

}
