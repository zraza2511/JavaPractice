package com.tw.Queue;

import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Comparator;

public class PriorityQueueTest {
	public static void main(String[] args) {
		Queue<Integer> priorityQueue = new PriorityQueue<>();

		// Adding elements to the priority queue
		priorityQueue.add(20);
		priorityQueue.add(10);
		priorityQueue.add(30);

		// Displaying the priority queue
		System.out.println("PriorityQueue: " + priorityQueue);

		// Removing an element from the priority queue
		Integer removed = priorityQueue.poll();
		System.out.println("Removed: " + removed);

		// Peeking the head of the priority queue
		Integer head = priorityQueue.peek();
		System.out.println("Head of priority queue: " + head);

		// Displaying the priority queue again
		System.out.println("PriorityQueue after poll: " + priorityQueue);

		// Peek at the head of the queue
		System.out.println("Head of the queue (peek): " + priorityQueue.peek());

		// Check if the queue contains certain elements
		System.out.println("Queue contains 30: " + priorityQueue.contains(30));

		// Remove an element
		System.out.println("Removing 30 from the queue: " + priorityQueue.remove(30));

		// Check if the queue is empty
		System.out.println("Queue is empty: " + priorityQueue.isEmpty());

		// Clearing the PriorityQueue using clear() method
		priorityQueue.clear();

		// Get the size of the queue
		System.out.println("Size of queue: " + priorityQueue.size());

		Comparator<Integer> num = (a, b) -> b - a;
		Queue<Integer> obj = new PriorityQueue<>(num);

		// Adding elements to the priority queue
		obj.add(20);
		obj.add(50);
		obj.add(60);
		obj.add(40);
		obj.add(10);
		obj.add(30);

		System.out.println("Comparator for descending order" + obj);

	}
}
