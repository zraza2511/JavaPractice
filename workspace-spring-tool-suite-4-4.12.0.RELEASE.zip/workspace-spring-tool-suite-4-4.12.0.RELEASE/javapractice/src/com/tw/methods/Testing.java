package com.tw.methods;

public class Testing {
	
	public static void main (String args[]) {
		test(10, 20);
		test2(40, 20);
		test3(10, 10);
		Testing obj=new Testing();
		obj.test4(100, 2);
		Testing obj1=new Testing();
		obj1.test5("Hello ","World.");
							
	}
	public static void test(int x,int y) {
		System.out.println("Hello Static Method= " + (x+y));
	}
	public static void test2(int x,int y) {
		System.out.println("Hello Static Method2= " + (x-y));
	}
	public static void test3(int x,int y) {
		System.out.println("Hello Static Method3= " + (x*y)); 
	}
	public void test4(int x,int y) {
		System.out.println("Hello Instance Method4= " + (x/y));
	}
	public void test5(String x,String y) {
		System.out.println("Hello Instance Method5= " + (x+y));
	}
	
}
