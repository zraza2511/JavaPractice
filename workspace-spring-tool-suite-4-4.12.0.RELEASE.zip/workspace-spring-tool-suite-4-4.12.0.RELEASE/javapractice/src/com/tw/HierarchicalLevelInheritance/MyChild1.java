package com.tw.HierarchicalLevelInheritance;

public class MyChild1 extends Parent {
	public String childName = "XYZ";

}
