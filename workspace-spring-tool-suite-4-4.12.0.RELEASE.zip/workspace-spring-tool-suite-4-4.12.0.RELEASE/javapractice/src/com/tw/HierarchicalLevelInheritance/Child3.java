package com.tw.HierarchicalLevelInheritance;

public class Child3 extends Parent {
	public String myName= "Mohammed Fahad";
}
