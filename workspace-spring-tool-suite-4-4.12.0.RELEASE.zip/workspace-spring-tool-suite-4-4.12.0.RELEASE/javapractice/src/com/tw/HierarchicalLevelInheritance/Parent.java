package com.tw.HierarchicalLevelInheritance;

public class Parent {
	public String fatherName= "Mohammed Nazeer";

}
