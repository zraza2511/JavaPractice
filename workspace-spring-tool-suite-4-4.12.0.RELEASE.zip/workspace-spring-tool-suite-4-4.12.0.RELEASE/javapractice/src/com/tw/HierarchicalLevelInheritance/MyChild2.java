package com.tw.HierarchicalLevelInheritance;

public class MyChild2 extends Parent {
	public String childName2 = "ABC";

}
