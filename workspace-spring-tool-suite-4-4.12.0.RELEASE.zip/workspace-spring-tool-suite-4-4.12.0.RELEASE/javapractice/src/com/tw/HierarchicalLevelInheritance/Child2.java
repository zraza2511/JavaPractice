package com.tw.HierarchicalLevelInheritance;

public class Child2 extends Parent {
	public String myName= "Mohammed Khaled";
}
