package com.tw.HierarchicalLevelInheritance;

public class Child extends Parent {
	public String myName= "Mohammed Junaid";
}
