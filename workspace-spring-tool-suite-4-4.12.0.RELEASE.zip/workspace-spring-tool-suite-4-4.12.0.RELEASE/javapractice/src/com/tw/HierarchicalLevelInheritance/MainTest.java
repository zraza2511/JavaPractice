package com.tw.HierarchicalLevelInheritance;

public class MainTest {

	public static void main(String[] args) {

		MyChild1 mc = new MyChild1();
		Child c = new Child();

		System.out.println("My Father Name: " + mc.fatherName);
		System.out.println("My Name: " + c.myName);
		System.out.println("My First Child Name: " + mc.childName);

	}

}
