package com.tw.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Student> students = new ArrayList<>();
        students.add(new Student(3, "Amir"));
        students.add(new Student(1, "Zeeshan"));
        students.add(new Student(2, "Junaid"));

        // Sort by roll number
        Collections.sort(students, new RollNumberComparator());
        System.out.println("Sorted by roll number:");
        for (Student student : students) {
            System.out.println(student);
        }

        // Sort by name
        Collections.sort(students, new NameComparator());
        System.out.println("Sorted by name:");
        for (Student student : students) {
            System.out.println(student);
        }
    }
}

