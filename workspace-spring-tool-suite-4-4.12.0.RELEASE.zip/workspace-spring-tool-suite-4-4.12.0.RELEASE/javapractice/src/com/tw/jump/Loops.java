package com.tw.jump;

public class Loops {

	public static void main(String[] args) {
		pattern1(5);
		pattern2(5);
		pattern3(5);
		pattern4(5);
		pattern5(5);
		pattern6(5);
		pattern7(5);
		pattern8(5);
		pattern9(5);
		pattern10(5);
		pattern11(5);
		pattern12(5);
		pattern13(5);
		pattern14(5);
		pattern15(5);
		//pattern16(5);

	}

	static void pattern1(int n) {
		for (int row = 1; row <= n; row++) {
			for (int col = 1; col <= n; col++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

	static void pattern2(int n) {
		for (int row = 1; row <= n; row++) {
			for (int col = 1; col <= row; col++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

	static void pattern3(int n) {
		for (int row = 1; row <= n; row++) {
			for (int col = 1; col <= n - row + 1; col++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

	static void pattern4(int n) {
		for (int row = 1; row <= n; row++) {
			for (int col = 1; col <= row; col++) {
				System.out.print(col + " ");
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

	static void pattern5(int n) {
		for (int row = 0; row < 2 * n; row++) {
			int totalColsInRow = row > n ? 2 * n - row : row;
			for (int col = 0; col < totalColsInRow; col++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

	static void pattern6(int n) {
		for (int row = 1; row <= n; row++) {
			for (int spaces = n - row; spaces > 0; spaces--) {
				System.out.print("  ");
			}
			for (int stars = 1; stars <= row; stars++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

	static void pattern7(int n) {
		for (int row = n; row >= 1; row--) {
			for (int spaces = 1; spaces <= n - row; spaces++) {
				System.out.print("  ");
			}
			for (int stars = 1; stars <= row; stars++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

	static void pattern8(int n) {
		for (int row = 1; row <= n; row++) {
			for (int spaces = n - row; spaces > 0; spaces--) {
				System.out.print(" ");
			}
			for (int stars = 1; stars <= row; stars++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

	static void pattern9(int n) {
		for (int row = 0; row < n; row++) {
			for (int spaces = 0; spaces < row; spaces++) {
				System.out.print(" ");
			}
			for (int stars = 0; stars < n - row; stars++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

	static void pattern10(int n) {
		for (int row = 0; row < n; row++) {
			System.out.print(" ".repeat(row));
			System.out.println("* ".repeat(n - row));
		}
		System.out.println();
		for (int row = 1; row <= n; row++) {
			System.out.print(" ".repeat(n - row));
			System.out.println("* ".repeat(row));
		}
		System.out.println("-------------------");
	}

	static void pattern11(int n) {
		for (int row = 1; row <= n; row++) {
			for (int col = 1; col <= 2 * n - 1; col++) {
				if (col == n - row + 1 || col == n + row - 1 || row == n) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

	static void pattern12(int n) {
		for (int row = 0; row < n; row++) {
			System.out.print(" ".repeat(row));
			for (int col = 0; col < 2 * n - 1 - 2 * row; col++) {
				System.out.print((row == 0 || col == 0 || col == 2 * n - 2 * row - 2) ? "*" : " ");
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

	static void pattern13(int n) {
		for (int i = -n + 1; i < n; i++) {
			int spaces = Math.abs(i);
			int stars = n - spaces;

			System.out.print(" ".repeat(spaces) + "*");
			if (stars > 1) {
				System.out.print(" ".repeat(2 * (stars - 1) - 1) + "*");
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}
	
	static void pattern14(int n) {
	   for (int i = 0; i < n; i++) {
           for (int j = 0; j < n - i - 1; j++) {
               System.out.print(" ");
           }
           int num = 1;
           for (int j = 0; j <= i; j++) {
               System.out.print(num + " ");
               num = num * (i - j) / (j + 1);
           }
           System.out.println();
       }
	   System.out.println("-------------------");
   }
	
	static void pattern15(int n) {
	    for (int i = 0; i < n; i++) {
        for (int j = 0; j < 2 * (n - i - 1); j++) {
            System.out.print(" ");
        }
        for (int j = 1; j <= i + 1; j++) {
            System.out.print((i + 1 - j + 1) + " ");
        }
        for (int j = 2; j <= i + 1; j++) {
            System.out.print(j + " ");
        }
        System.out.println();
    }
	System.out.println("-------------------");
}
}
