package com.tw.jump;

public class RightAlignedTriangle {
		    public static void main(String[] args) {
	        int n = 5; // Number of rows in the pattern

	        for (int i = 0; i < n; i++) {
	            for (int j = 0; j < 2 * (n - i - 1); j++) {
	                System.out.print(" ");
	            }
	            for (int j = 1; j <= i + 1; j++) {
	                System.out.print((i + 1 - j + 1) + " ");
	            }
	            for (int j = 2; j <= i + 1; j++) {
	                System.out.print(j + " ");
	            }
	            System.out.println();
	        }
	    }
	}


