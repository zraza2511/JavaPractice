package com.tw.jump;

public class JumpStatmentTest {
	
	public static int sum (int a, int b) {
		int sum = a+b;
		return sum;
	}

	public static void main(String[] args) {
		
		int day = 3;
		String dayName;
		
		switch (day) {
			case 1:
				dayName = "Sunday";
				break;
			case 2:
				dayName = "Monday";
				break;
			case 3:
				dayName = "Tuesday";
				break;
			case 4:
				dayName = "Wednesday";
				break;
			case 5:
				dayName = "Thursday";
				break;
			case 6:
				dayName = "Friday";
				break;
			case 7:
				dayName = "Saturday";
				break;
			default:
					dayName = "Invalid day";
					break;		
							
		}
		
		for (int i=0; i<10; i++) {
			if (i>5) {
				continue;
			}
			
			
			
		int result = sum (5,5);
			
			System.out.println("sum: " + result );
			
			System.out.println("Continue: " + i);
		}
		
		System.out.println("The day is " + dayName);
		}

}
