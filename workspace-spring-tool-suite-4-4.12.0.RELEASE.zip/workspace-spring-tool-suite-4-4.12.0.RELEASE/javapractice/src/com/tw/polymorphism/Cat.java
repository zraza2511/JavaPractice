package com.tw.polymorphism;

public class Cat extends Animal {
	
	@Override
	
	public void speak() {
		System.out.println("Meow Meow this is a cat sound");
	}

}
