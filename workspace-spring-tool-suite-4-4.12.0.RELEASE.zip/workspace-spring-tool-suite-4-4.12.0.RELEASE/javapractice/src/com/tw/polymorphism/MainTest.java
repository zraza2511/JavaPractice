package com.tw.polymorphism;

public class MainTest {

	public static void main(String[] args) {
		
		Animal sound = new Animal();
		Animal dog = new Dog();
		Animal cat = new Cat();
		Calculator cal = new Calculator();
				
		sound.speak();
		dog.speak();
		cat.speak();
		
		System.out.println("Overloading: "+cal.add(2,3));
		System.out.println("Overloading: "+cal.add(2,3,4));
		System.out.println("Overloading: "+cal.add(2.5,3.5));
		

	}

}
