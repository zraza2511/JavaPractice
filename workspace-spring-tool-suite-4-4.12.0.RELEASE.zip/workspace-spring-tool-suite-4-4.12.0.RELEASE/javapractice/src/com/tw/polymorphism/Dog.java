package com.tw.polymorphism;

public class Dog extends Animal {
	
	@Override
	
	public void speak() {
		System.out.println("Bhao Bhao this is a dog sound");
	}
	

}
