package com.tw.polymorphism;

public class Animal {
	
	public void speak() {
		System.out.println("The animal makes a sound");
	}

}
