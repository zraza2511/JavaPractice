package com.tw;

import com.tw.ds.DiffPackDiffClass;

public class SameClass {

	public String p = "Public Access Modifier";
	private String pr = "Private Access Modifier";
	protected String pro = "Protected Access Modifier";
	String d = "Default Access Modifier";

	void sClass() {

		// Uncomment if you want to print the fields here

		System.out.println(p);
		System.out.println(pr);
		System.out.println(pro);
		System.out.println(d);

	}

	public class SubClass extends SameClass {

		void suClass() {
			System.out.println(p);
			System.out.println(pr); // Accessible because SubClass is an inner class
			System.out.println(pro);
			System.out.println(d);
		}
	}

	public static void main(String[] args) {
		SameClass s = new SameClass();
		s.sClass();

//		 Correct way to instantiate SubClass
		SameClass.SubClass ss = s.new SubClass();
		ss.suClass();

//		DiffPackDiffClass d = new DiffPackDiffClass();
//		System.out.println(d.st);
	}
}
