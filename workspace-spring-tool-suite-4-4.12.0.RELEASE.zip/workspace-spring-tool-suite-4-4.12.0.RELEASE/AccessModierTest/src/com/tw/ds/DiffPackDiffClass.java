package com.tw.ds;

public class DiffPackDiffClass {
	
	
	protected
	String st="something";
	
	
		
		//  System.out.println(p); 
		//  System.out.println(pr);
		// System.out.println(pro);
		//  System.out.println(d);
		 
		
		
	

}
