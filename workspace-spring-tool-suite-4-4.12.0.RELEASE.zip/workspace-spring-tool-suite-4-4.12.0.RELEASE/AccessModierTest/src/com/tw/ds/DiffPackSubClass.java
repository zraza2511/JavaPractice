package com.tw.ds;

import com.tw.SameClass;

public class DiffPackSubClass extends SameClass {
	
	void meth() {
		
		System.out.println(p);
		// System.out.println(pr);
		 System.out.println(pro);
		// System.out.println(d);

		
	}

	public static void main(String[] args) {
		
		DiffPackSubClass obj1 = new DiffPackSubClass();
		obj1.meth();
		SameClass obj = new SameClass();

		   System.out.println(obj.p);
		// System.out.println(pr);
		// System.out.println(pro);
		// System.out.println(d);

	}

}
